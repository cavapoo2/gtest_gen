//=============================================================================
// GTestGen – C++ Parameterised Test Scaffold Generator
//
// Usage:
//   GTestGen.exe <HeaderFile.h> [options]
//
// Options:
//   -o <dir>         Output directory (default: ./generated)
//   --impl <file>    Implementation .cpp for branch-coverage analysis
//   --namespace <ns> Optional namespace to wrap generated tests
//   --cmake          Also emit a CMakeLists.txt
//   --verbose        Verbose logging
//   --help           Show this help
//=============================================================================

#include "ClassParser.h"
#include "ImplParser.h"
#include "TestGenerator.h"
#include "GeneratorConfig.h"

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

namespace
{
    void PrintUsage(const char* exe)
    {
        std::cout <<
            "GTestGen – C++ Parameterised GTest/GMock Scaffold Generator\n"
            "------------------------------------------------------------\n"
            "Usage:\n"
            "  " << exe << " <HeaderFile.h> [options]\n\n"
            "Options:\n"
            "  -o <dir>          Output directory                  (default: ./generated)\n"
            "  --impl <file.cpp> Implementation source for branch  (default: none)\n"
            "                    analysis; generates TODO rows for every if/else/\n"
            "                    switch/return/ternary/loop branch found.\n"
            "  --legacy-mock     Use MOCK_METHODn / MOCK_CONST_METHODn macro style\n"
            "                    for GMock versions before 1.10.\n"
            "                    Default: modern MOCK_METHOD(..., (override)) style.\n"
            "  --namespace <ns>  Namespace for test code           (default: none)\n"
            "  --cmake           Emit CMakeLists.txt               (default: off)\n"
            "  --verbose         Verbose diagnostic output         (default: off)\n"
            "  --help            Print this message\n\n"
            "Generated files:\n"
            "  MockInterfaces.h          GMock class for every injected interface\n"
            "  <ClassName>TestFixture.h  GTest fixture (friend of class under test)\n"
            "  <ClassName>Tests.cpp      TEST_P for every public + private method,\n"
            "                            with branch-coverage TODOs when --impl is used\n"
            "  CMakeLists.txt            (only with --cmake)\n\n"
            "Quick start:\n"
            "  1. Run GTestGen on your header (and optionally --impl your .cpp).\n"
            "  2. Add  friend class <ClassName>Tests;  to your class (as indicated).\n"
            "  3. Fill in MOCK_METHOD entries in MockInterfaces.h.\n"
            "  4. Add one INSTANTIATE row per branch TODO in <ClassName>Tests.cpp.\n"
            "  5. Build and run to confirm all stubs pass, then fill in real assertions.\n";
    }

    struct Args
    {
        std::string inputHeader;
        GTestGen::GeneratorConfig cfg;
        bool helpRequested = false;
        bool valid = false;
    };

    Args ParseArgs(int argc, char* argv[])
    {
        Args a;
        a.cfg.outputDir = "./generated";

        if (argc < 2)
        {
            a.helpRequested = true;
            return a;
        }

        std::vector<std::string> tokens(argv + 1, argv + argc);

        for (std::size_t i = 0; i < tokens.size(); ++i)
        {
            const std::string& tok = tokens[i];

            if (tok == "--help" || tok == "-h")
            {
                a.helpRequested = true;
                return a;
            }
            else if (tok == "-o" && i + 1 < tokens.size())
            {
                a.cfg.outputDir = tokens[++i];
            }
            else if (tok == "--impl" && i + 1 < tokens.size())
            {
                a.cfg.implSourcePath = tokens[++i];
            }
            else if (tok == "--namespace" && i + 1 < tokens.size())
            {
                a.cfg.testNamespace = tokens[++i];
            }
            else if (tok == "--cmake")
            {
                a.cfg.generateCMake = true;
            }
            else if (tok == "--legacy-mock")
            {
                a.cfg.legacyMockMacros = true;
            }
            else if (tok == "--verbose" || tok == "-v")
            {
                a.cfg.verbose = true;
            }
            else if (tok[0] != '-')
            {
                // First positional argument is the header file
                if (a.inputHeader.empty())
                    a.inputHeader = tok;
                else
                {
                    std::cerr << "Unexpected argument: " << tok << "\n";
                    return a;
                }
            }
            else
            {
                std::cerr << "Unknown option: " << tok << "\n";
                return a;
            }
        }

        if (a.inputHeader.empty())
        {
            std::cerr << "Error: no input header file specified.\n";
            return a;
        }

        a.cfg.inputHeaderPath = a.inputHeader;
        a.valid = true;
        return a;
    }
}

int main(int argc, char* argv[])
{
    Args args = ParseArgs(argc, argv);

    if (args.helpRequested)
    {
        PrintUsage(argv[0]);
        return 0;
    }

    if (!args.valid)
    {
        PrintUsage(argv[0]);
        return 1;
    }

    // -------------------------------------------------------------------------
    // Step 1: Parse the class header
    // -------------------------------------------------------------------------
    std::cout << "Parsing: " << args.inputHeader << "\n";

    auto classInfo = GTestGen::ClassParser::Parse(args.inputHeader, args.cfg.verbose);
    if (!classInfo)
    {
        std::cerr << "Parsing failed. Aborting.\n";
        return 2;
    }

    std::cout << "Class     : " << classInfo->className << "\n";
    std::cout << "Public    : " << classInfo->publicMethods.size()  << " methods\n";

    // List public method names so the user can confirm they were all parsed
    for (auto& m : classInfo->publicMethods)
    {
        if (m.isConstructor || m.isDestructor) continue;
        std::cout << "              " << m.returnType << " " << m.name << "(";
        for (std::size_t i = 0; i < m.params.size(); ++i)
        {
            if (i > 0) std::cout << ", ";
            std::cout << m.params[i].type << " " << m.params[i].name;
        }
        std::cout << ")" << (m.isConst ? " const" : "") << "\n";
    }

    std::cout << "Private   : " << classInfo->privateMethods.size() << " methods\n";
    for (auto& m : classInfo->privateMethods)
    {
        if (m.isConstructor || m.isDestructor) continue;
        std::cout << "              " << m.returnType << " " << m.name << "(...)\n";
    }

    std::cout << "Interfaces: " << classInfo->interfaces.size() << " detected";
    if (classInfo->interfaces.empty())
        std::cout << " (none – constructor takes no interface pointer params)\n";
    else
    {
        std::cout << "\n";
        for (auto& iface : classInfo->interfaces)
            std::cout << "              " << iface.interfaceName
                      << "  →  Mock: " << iface.mockName << "\n";
    }

    // -------------------------------------------------------------------------
    // Step 2: Run ImplParser if --impl was supplied, always report what happened
    // -------------------------------------------------------------------------
    if (!args.cfg.implSourcePath.empty())
    {
        std::cout << "Impl      : " << args.cfg.implSourcePath << "\n";

        // Run a standalone diagnostic pass first so the user always sees
        // exactly what was found, regardless of --verbose.
        // We pass verbose=true here unconditionally so body/hint counts print.
        GTestGen::ClassInfo diag = *classInfo;
        bool implOk = GTestGen::ImplParser::Parse(
                            args.cfg.implSourcePath,
                            classInfo->className,
                            diag.publicMethods,
                            diag.privateMethods,
                            /*verbose=*/true);

        if (!implOk)
        {
            std::cerr << "  ERROR: Could not read impl file. Check the path.\n";
            std::cerr << "  Continuing without branch hints.\n";
        }
        else
        {
            // Summarise per-method hint counts
            std::size_t total = 0;
            auto report = [&](const std::vector<GTestGen::MethodInfo>& methods,
                               const char* label)
            {
                for (auto& m : methods)
                {
                    if (m.branchHints.empty()) continue;
                    std::cout << "  [" << label << "] " << m.name
                              << " → " << m.branchHints.size() << " hint(s)\n";
                    for (auto& h : m.branchHints)
                        std::cout << "      [" << GTestGen::BranchKindLabel(h.kind)
                                  << "] " << h.description << "\n";
                    total += m.branchHints.size();
                }
            };
            report(diag.publicMethods,  "public");
            report(diag.privateMethods, "private");

            if (total == 0)
            {
                std::cout << "  WARNING: 0 branch hints found.\n";
                std::cout << "  Possible causes:\n";
                std::cout << "    - Class name in the .cpp does not match '" 
                          << classInfo->className << "'\n";
                std::cout << "      (check for namespaces or typos — the tool looks for '"
                          << classInfo->className << "::')\n";
                std::cout << "    - The .cpp file path is wrong (file was opened but may be empty)\n";
                std::cout << "    - All methods are defined inline in the header\n";
                std::cout << "    - The method bodies have no branches (if/switch/return etc.)\n";
            }
            else
            {
                std::cout << "  Total: " << total << " branch hint(s) across all methods\n";
            }
        }
    }
    else
    {
        std::cout << "Impl      : (none – use --impl <file.cpp> for branch coverage hints)\n";
    }

    // -------------------------------------------------------------------------
    // Step 3: Generate test scaffold files
    // -------------------------------------------------------------------------
    std::cout << "\nGenerating to: " << args.cfg.outputDir << "\n";

    bool ok = GTestGen::TestGenerator::Generate(*classInfo, args.cfg);
    if (!ok)
    {
        std::cerr << "Generation failed. Check output directory permissions.\n";
        return 3;
    }

    std::cout << "Done.\n\n";
    std::cout << "Next steps:\n";
    std::cout << "  1. Open " << args.cfg.outputDir << "/Mock" << classInfo->className << ".h\n";
    std::cout << "     – all public methods are mocked; private methods listed as comments.\n";
    std::cout << "  2. Open " << args.cfg.outputDir << "/MockInterfaces.h\n";
    std::cout << "     and add MOCK_METHOD entries for each injected interface.\n";
    std::cout << "  3. Add  friend class " << classInfo->className << "FixtureBase;\n";
    std::cout << "     to " << classInfo->className << ".h (private section).\n";
    std::cout << "  4. Extend " << classInfo->className << "TestParams with\n";
    std::cout << "     test-specific input/output fields.\n";
    std::cout << "  5. Build " << classInfo->className << "Tests and run all TEST_P cases.\n";

    return 0;
}
