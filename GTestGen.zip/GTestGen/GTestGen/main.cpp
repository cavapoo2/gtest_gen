//=============================================================================
// GTestGen – C++ Parameterised Test Scaffold Generator
//
// Usage:
//   GTestGen.exe <HeaderFile.h> [options]
//
// Options:
//   -o <dir>         Output directory (default: ./generated)
//   --impl <file>    Implementation .cpp for branch-coverage analysis
//   --namespace <ns> Optional namespace to wrap generated tests
//   --cmake          Also emit a CMakeLists.txt
//   --verbose        Verbose logging
//   --help           Show this help
//=============================================================================

#include "ClassParser.h"
#include "TestGenerator.h"
#include "GeneratorConfig.h"

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

namespace
{
    void PrintUsage(const char* exe)
    {
        std::cout <<
            "GTestGen – C++ Parameterised GTest/GMock Scaffold Generator\n"
            "------------------------------------------------------------\n"
            "Usage:\n"
            "  " << exe << " <HeaderFile.h> [options]\n\n"
            "Options:\n"
            "  -o <dir>          Output directory                  (default: ./generated)\n"
            "  --impl <file.cpp> Implementation source for branch  (default: none)\n"
            "                    analysis; generates TODO rows for every if/else/\n"
            "                    switch/return/ternary/loop branch found.\n"
            "  --namespace <ns>  Namespace for test code           (default: none)\n"
            "  --cmake           Emit CMakeLists.txt               (default: off)\n"
            "  --verbose         Verbose diagnostic output         (default: off)\n"
            "  --help            Print this message\n\n"
            "Generated files:\n"
            "  MockInterfaces.h          GMock class for every injected interface\n"
            "  <ClassName>TestFixture.h  GTest fixture (friend of class under test)\n"
            "  <ClassName>Tests.cpp      TEST_P for every public + private method,\n"
            "                            with branch-coverage TODOs when --impl is used\n"
            "  CMakeLists.txt            (only with --cmake)\n\n"
            "Quick start:\n"
            "  1. Run GTestGen on your header (and optionally --impl your .cpp).\n"
            "  2. Add  friend class <ClassName>Tests;  to your class (as indicated).\n"
            "  3. Fill in MOCK_METHOD entries in MockInterfaces.h.\n"
            "  4. Add one INSTANTIATE row per branch TODO in <ClassName>Tests.cpp.\n"
            "  5. Build and run to confirm all stubs pass, then fill in real assertions.\n";
    }

    struct Args
    {
        std::string inputHeader;
        GTestGen::GeneratorConfig cfg;
        bool helpRequested = false;
        bool valid = false;
    };

    Args ParseArgs(int argc, char* argv[])
    {
        Args a;
        a.cfg.outputDir = "./generated";

        if (argc < 2)
        {
            a.helpRequested = true;
            return a;
        }

        std::vector<std::string> tokens(argv + 1, argv + argc);

        for (std::size_t i = 0; i < tokens.size(); ++i)
        {
            const std::string& tok = tokens[i];

            if (tok == "--help" || tok == "-h")
            {
                a.helpRequested = true;
                return a;
            }
            else if (tok == "-o" && i + 1 < tokens.size())
            {
                a.cfg.outputDir = tokens[++i];
            }
            else if (tok == "--impl" && i + 1 < tokens.size())
            {
                a.cfg.implSourcePath = tokens[++i];
            }
            else if (tok == "--namespace" && i + 1 < tokens.size())
            {
                a.cfg.testNamespace = tokens[++i];
            }
            else if (tok == "--cmake")
            {
                a.cfg.generateCMake = true;
            }
            else if (tok == "--verbose" || tok == "-v")
            {
                a.cfg.verbose = true;
            }
            else if (tok[0] != '-')
            {
                // First positional argument is the header file
                if (a.inputHeader.empty())
                    a.inputHeader = tok;
                else
                {
                    std::cerr << "Unexpected argument: " << tok << "\n";
                    return a;
                }
            }
            else
            {
                std::cerr << "Unknown option: " << tok << "\n";
                return a;
            }
        }

        if (a.inputHeader.empty())
        {
            std::cerr << "Error: no input header file specified.\n";
            return a;
        }

        a.cfg.inputHeaderPath = a.inputHeader;
        a.valid = true;
        return a;
    }
}

int main(int argc, char* argv[])
{
    Args args = ParseArgs(argc, argv);

    if (args.helpRequested)
    {
        PrintUsage(argv[0]);
        return 0;
    }

    if (!args.valid)
    {
        PrintUsage(argv[0]);
        return 1;
    }

    // -------------------------------------------------------------------------
    // Step 1: Parse the class header
    // -------------------------------------------------------------------------
    std::cout << "Parsing: " << args.inputHeader << "\n";

    auto classInfo = GTestGen::ClassParser::Parse(args.inputHeader, args.cfg.verbose);
    if (!classInfo)
    {
        std::cerr << "Parsing failed. Aborting.\n";
        return 2;
    }

    std::cout << "Class     : " << classInfo->className << "\n";
    std::cout << "Public    : " << classInfo->publicMethods.size()  << " methods\n";
    std::cout << "Private   : " << classInfo->privateMethods.size() << " methods\n";
    std::cout << "Interfaces: " << classInfo->interfaces.size()     << " detected\n";
    if (!args.cfg.implSourcePath.empty())
        std::cout << "Impl      : " << args.cfg.implSourcePath << " (branch analysis enabled)\n";
    else
        std::cout << "Impl      : (none – use --impl <file.cpp> for branch coverage hints)\n";

    // -------------------------------------------------------------------------
    // Step 2: Generate test scaffold files
    // -------------------------------------------------------------------------
    std::cout << "Generating to: " << args.cfg.outputDir << "\n";

    bool ok = GTestGen::TestGenerator::Generate(*classInfo, args.cfg);
    if (!ok)
    {
        std::cerr << "Generation failed. Check output directory permissions.\n";
        return 3;
    }

    std::cout << "Done.\n\n";
    std::cout << "Next steps:\n";
    std::cout << "  1. Open " << args.cfg.outputDir << "/MockInterfaces.h\n";
    std::cout << "     and add MOCK_METHOD entries for each interface.\n";
    std::cout << "  2. Add  friend class " << classInfo->className << "Tests;\n";
    std::cout << "     to " << classInfo->className << ".h (private section).\n";
    std::cout << "  3. Extend " << classInfo->className << "TestParams with\n";
    std::cout << "     test-specific input/output fields.\n";
    std::cout << "  4. Build " << classInfo->className << "Tests and run all TEST_P cases.\n";

    return 0;
}
