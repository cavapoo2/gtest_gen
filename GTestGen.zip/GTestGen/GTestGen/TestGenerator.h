#pragma once
#include "GeneratorConfig.h"
#include <string>

namespace GTestGen
{
    /// Generates five files from a parsed ClassInfo:
    ///
    ///   1. Mock<ClassName>.h         – GMock class for the class under test itself
    ///   2. MockInterfaces.h          – GMock stubs for injected interface dependencies
    ///   3. <ClassName>TestFixture.h  – Shared fixture base + per-method fixture classes
    ///   4. <ClassName>Tests.cpp      – Per-method TEST_P + INSTANTIATE blocks
    ///   5. CMakeLists.txt            – minimal CMake snippet (optional)
    ///
    /// Each method under test gets its own param struct, fixture class, and
    /// INSTANTIATE_TEST_SUITE_P so test data is not shared across methods.
    ///
    /// All output is written to GeneratorConfig::outputDir.
    class TestGenerator
    {
    public:
        /// Returns false on I/O error; writes progress to stdout.
        static bool Generate(const ClassInfo& info, const GeneratorConfig& cfg);

    private:
        // --- Per-file generators ------------------------------------------------
        static std::string BuildMockClassHeader     (const ClassInfo& info,
                                                      const GeneratorConfig& cfg);
        static std::string BuildMockInterfacesHeader(const ClassInfo& info);
        static std::string BuildTestFixtureHeader   (const ClassInfo& info,
                                                      const GeneratorConfig& cfg);
        static std::string BuildParameterisedTests  (const ClassInfo& info,
                                                      const GeneratorConfig& cfg);
        static std::string BuildCMakeLists          (const ClassInfo& info,
                                                      const GeneratorConfig& cfg);

        // --- Per-method building blocks -----------------------------------------
        static std::string MethodParamStructName  (const ClassInfo& info,
                                                    const MethodInfo& method);
        static std::string MethodFixtureName      (const ClassInfo& info,
                                                    const MethodInfo& method);
        static std::string MethodParamStruct      (const ClassInfo& info,
                                                    const MethodInfo& method);
        static std::string MethodFixtureClass     (const ClassInfo& info,
                                                    const MethodInfo& method);
        static std::string TestCaseBlock          (const MethodInfo& method,
                                                    const ClassInfo& info,
                                                    bool isPrivate);
        static std::string InstantiateBlock       (const MethodInfo& method,
                                                    const ClassInfo& info,
                                                    bool isPrivate);

        // --- Shared fixture building blocks -------------------------------------
        static std::string FormatMockMethod       (const MethodInfo& method,
                                                    bool legacyMacros);
        static std::string MockClassBlock         (const InterfaceInfo& iface);
        static std::string FixtureBaseClass       (const ClassInfo& info);
        static std::string FixturePrivateHelpers  (const ClassInfo& info);

        // --- Helpers ------------------------------------------------------------
        static std::string DefaultValueFor        (const std::string& type);
        static std::string FormatParamList        (const std::vector<MethodParam>& params,
                                                    bool withTypes = true);
        static std::string FormatCallArgs         (const std::vector<MethodParam>& params);
        static bool        WriteFile              (const std::string& path,
                                                    const std::string& content);
    };

} // namespace GTestGen
