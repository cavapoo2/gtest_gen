#pragma once
#include "GeneratorConfig.h"
#include <string>

namespace GTestGen
{
    /// Generates four files from a parsed ClassInfo:
    ///
    ///   1. MockInterfaces.h          – GMock classes for every detected interface
    ///   2. <ClassName>TestFixture.h  – GTest fixture (TestWithParam), friend of the CUT
    ///   3. <ClassName>Tests.cpp      – TEST_P for every public + private method
    ///   4. CMakeLists.txt            – minimal CMake snippet (optional)
    ///
    /// All output is written to GeneratorConfig::outputDir.
    class TestGenerator
    {
    public:
        /// Returns false on I/O error; writes progress to stdout.
        static bool Generate(const ClassInfo& info, const GeneratorConfig& cfg);

    private:
        // --- Per-file generators ------------------------------------------------
        static std::string BuildMockInterfacesHeader(const ClassInfo& info);
        static std::string BuildTestFixtureHeader   (const ClassInfo& info,
                                                      const GeneratorConfig& cfg);
        static std::string BuildParameterisedTests  (const ClassInfo& info,
                                                      const GeneratorConfig& cfg);
        static std::string BuildCMakeLists          (const ClassInfo& info,
                                                      const GeneratorConfig& cfg);

        // --- Building blocks ----------------------------------------------------
        static std::string MockClassBlock      (const InterfaceInfo& iface);
        static std::string InferredMockMethods (const InterfaceInfo& iface,
                                                const ClassInfo& info);
        static std::string FixturePrivateHelpers(const ClassInfo& info);
        static std::string TestCaseBlock       (const MethodInfo& method,
                                                const ClassInfo& info,
                                                bool isPrivate,
                                                int  paramIndex);
        static std::string DefaultValueFor     (const std::string& type);
        static std::string ParamStructName     (const ClassInfo& info);
        static std::string FormatParamList     (const std::vector<MethodParam>& params,
                                                bool withTypes = true);
        static std::string FormatCallArgs      (const std::vector<MethodParam>& params);
        static bool        WriteFile           (const std::string& path,
                                                const std::string& content);
    };

} // namespace GTestGen
