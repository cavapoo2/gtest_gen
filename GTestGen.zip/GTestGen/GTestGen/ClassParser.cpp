#include "ClassParser.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <regex>
#include <algorithm>
#include <cctype>
#include <set>

namespace GTestGen
{

// =============================================================================
// Public entry point
// =============================================================================

std::optional<ClassInfo> ClassParser::Parse(const std::string& path, bool verbose)
{
    // 1. Read raw source
    std::string src = ReadFile(path);
    if (src.empty())
    {
        std::cerr << "[ClassParser] Cannot read file: " << path << "\n";
        return std::nullopt;
    }

    // 2. Collect #include lines before stripping
    ClassInfo info;
    {
        std::istringstream ss(src);
        std::string line;
        while (std::getline(ss, line))
        {
            std::string trimmed = Trim(line);
            if (trimmed.rfind("#include", 0) == 0)
                info.existingIncludes.push_back(trimmed);
        }
    }

    // 3. Pre-process
    std::string clean = StripComments(src);
    clean = StripPreprocessor(clean);

    // 4. Find class name
    auto className = ExtractClassName(clean);
    if (!className)
    {
        std::cerr << "[ClassParser] No class declaration found in: " << path << "\n";
        return std::nullopt;
    }
    info.className   = *className;
    info.headerGuard = DeriveHeaderGuard(*className);

    if (verbose)
        std::cout << "[ClassParser] Found class: " << info.className << "\n";

    // 5. Isolate the class body (between the outermost braces after 'class X')
    std::string classBody;
    {
        auto classPos = clean.find("class " + info.className);
        if (classPos == std::string::npos)
            classPos = clean.find("struct " + info.className);

        if (classPos == std::string::npos)
        {
            std::cerr << "[ClassParser] Cannot locate class body.\n";
            return std::nullopt;
        }

        auto openBrace = clean.find('{', classPos);
        if (openBrace == std::string::npos)
        {
            std::cerr << "[ClassParser] No opening brace for class body.\n";
            return std::nullopt;
        }

        // Match braces
        int depth = 0;
        std::size_t closeBrace = std::string::npos;
        for (std::size_t i = openBrace; i < clean.size(); ++i)
        {
            if (clean[i] == '{') ++depth;
            else if (clean[i] == '}')
            {
                --depth;
                if (depth == 0) { closeBrace = i; break; }
            }
        }
        if (closeBrace == std::string::npos)
        {
            std::cerr << "[ClassParser] Unbalanced braces in class body.\n";
            return std::nullopt;
        }
        classBody = clean.substr(openBrace + 1, closeBrace - openBrace - 1);
    }

    // 6. Walk access sections
    ParseAccessSections(classBody, info);

    // 7. Derive interface list from constructors
    ParseConstructorInterfaces(info, info);

    if (verbose)
    {
        std::cout << "[ClassParser]  Public methods  : " << info.publicMethods.size()  << "\n";
        std::cout << "[ClassParser]  Private methods : " << info.privateMethods.size() << "\n";
        std::cout << "[ClassParser]  Interfaces      : " << info.interfaces.size()     << "\n";
    }

    return info;
}

// =============================================================================
// Text pre-processing
// =============================================================================

std::string ClassParser::ReadFile(const std::string& path)
{
    std::ifstream f(path);
    if (!f.is_open()) return {};
    return { std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>() };
}

std::string ClassParser::StripComments(const std::string& src)
{
    std::string out;
    out.reserve(src.size());
    std::size_t i = 0;
    while (i < src.size())
    {
        // Block comment
        if (i + 1 < src.size() && src[i] == '/' && src[i + 1] == '*')
        {
            i += 2;
            while (i + 1 < src.size() && !(src[i] == '*' && src[i + 1] == '/'))
            {
                if (src[i] == '\n') out += '\n'; // preserve newlines for line tracking
                ++i;
            }
            i += 2;
        }
        // Line comment
        else if (i + 1 < src.size() && src[i] == '/' && src[i + 1] == '/')
        {
            while (i < src.size() && src[i] != '\n') ++i;
        }
        // String literals – keep but don't interpret content
        else if (src[i] == '"')
        {
            out += src[i++];
            while (i < src.size() && src[i] != '"')
            {
                if (src[i] == '\\') { out += src[i++]; } // escape
                out += src[i++];
            }
            if (i < src.size()) out += src[i++]; // closing "
        }
        else
        {
            out += src[i++];
        }
    }
    return out;
}

std::string ClassParser::StripPreprocessor(const std::string& src)
{
    // Remove #pragma, #ifndef, #define, #endif lines but keep #include for later
    std::istringstream ss(src);
    std::ostringstream out;
    std::string line;
    while (std::getline(ss, line))
    {
        std::string t = Trim(line);
        if (!t.empty() && t[0] == '#')
        {
            if (t.rfind("#include", 0) == 0)
                out << "\n"; // blank placeholder to keep line numbers
            else
                out << "\n"; // strip, keep newline
        }
        else
        {
            out << line << "\n";
        }
    }
    return out.str();
}

// =============================================================================
// Class-name extraction
// =============================================================================

std::optional<std::string> ClassParser::ExtractClassName(const std::string& src)
{
    // Match: class Foo [: ...] {  or  struct Foo [: ...] {
    std::regex re(R"(\b(?:class|struct)\s+(\w+)\s*(?:final\s*)?(?::[^{]*)?\{)");
    std::smatch m;
    if (std::regex_search(src, m, re))
        return m[1].str();
    return std::nullopt;
}

// =============================================================================
// Access section parser
// =============================================================================

void ClassParser::ParseAccessSections(const std::string& classBody, ClassInfo& out)
{
    // Split on access specifiers. Default for 'class' is private; 'struct' is public.
    // We treat the first (unlabelled) section as private for class, public for struct.

    // Tokenise into sections: (access_label, body_text)
    struct Section { std::string label; std::string body; };
    std::vector<Section> sections;

    std::regex accessRe(R"(\b(public|private|protected)\s*:)");
    std::sregex_iterator it(classBody.begin(), classBody.end(), accessRe);
    std::sregex_iterator end;

    std::size_t prev = 0;
    std::string prevLabel = "private"; // class default

    for (; it != end; ++it)
    {
        std::size_t matchPos = static_cast<std::size_t>(it->position());
        sections.push_back({ prevLabel, classBody.substr(prev, matchPos - prev) });
        prevLabel = (*it)[1].str();
        prev = matchPos + (*it)[0].length();
    }
    sections.push_back({ prevLabel, classBody.substr(prev) });

    // Parse each section
    for (auto& sec : sections)
    {
        bool isPrivate = (sec.label == "private");
        bool skipSection = (sec.label == "protected"); // treat protected as private for simplicity

        // Split body into individual declarations (semicolon-terminated)
        // Careful: must balance angle brackets and parens for templates
        std::vector<std::string> decls;
        std::string current;
        int angleDepth = 0, parenDepth = 0, braceDepth = 0;

        for (char c : sec.body)
        {
            if (c == '<') ++angleDepth;
            else if (c == '>') { if (angleDepth > 0) --angleDepth; }
            else if (c == '(') ++parenDepth;
            else if (c == ')') { if (parenDepth > 0) --parenDepth; }
            else if (c == '{') ++braceDepth;
            else if (c == '}') { if (braceDepth > 0) --braceDepth; }

            if (c == ';' && angleDepth == 0 && parenDepth == 0 && braceDepth == 0)
            {
                std::string d = Trim(current);
                if (!d.empty()) decls.push_back(d);
                current.clear();
            }
            else if (c == '{' && braceDepth == 1 && parenDepth == 0)
            {
                // Inline method body start: consume until matching }
                // (already incremented braceDepth above)
                // Just record the declaration part we have so far
                std::string d = Trim(current);
                if (!d.empty()) decls.push_back(d);
                current.clear();
            }
            else
            {
                if (braceDepth == 0)
                    current += c;
            }
        }
        if (!Trim(current).empty())
            decls.push_back(Trim(current));

        for (auto& decl : decls)
        {
            std::string d = Trim(decl);
            if (d.empty()) continue;

            // Skip friend declarations (we insert our own)
            if (d.find("friend") != std::string::npos) continue;
            // Skip using / typedef
            if (d.rfind("using", 0) == 0 || d.rfind("typedef", 0) == 0) continue;
            // Skip 'class' / 'struct' nested types
            if (d.rfind("class ", 0) == 0 || d.rfind("struct ", 0) == 0) continue;
            // Skip enum
            if (d.rfind("enum", 0) == 0) continue;

            // Detect member variable vs method
            bool hasParens = d.find('(') != std::string::npos;

            if (hasParens)
            {
                auto method = ParseMethodDecl(d, isPrivate || skipSection);
                if (method)
                {
                    if (method->isPrivate)
                        out.privateMethods.push_back(*method);
                    else
                        out.publicMethods.push_back(*method);
                }
            }
            else
            {
                auto member = ParseMemberVar(d);
                if (member)
                    out.memberVars.push_back(*member);
            }
        }
    }
}

// =============================================================================
// Method declaration parser
// =============================================================================

std::optional<MethodInfo> ClassParser::ParseMethodDecl(const std::string& decl, bool isPrivate)
{
    MethodInfo m;
    m.isPrivate = isPrivate;

    std::string d = decl;

    // Detect qualifiers
    m.isVirtual     = (d.find("virtual")  != std::string::npos);
    m.isPureVirtual = (d.find("= 0")      != std::string::npos);
    m.isOverride    = (d.find("override") != std::string::npos);
    m.isConst       = false; // detected below

    // Strip qualifiers that would confuse the name/return-type parse
    for (const char* kw : { "virtual ", "explicit ", "inline ", "static ", "override", "final", "= 0", "= default", "= delete" })
    {
        std::size_t pos;
        while ((pos = d.find(kw)) != std::string::npos)
            d.erase(pos, std::strlen(kw));
    }
    d = Trim(d);

    // Detect const after param list: "... ) const"
    {
        auto constPos = d.rfind(") const");
        if (constPos != std::string::npos)
        {
            m.isConst = true;
            d.erase(constPos + 1, 6); // remove " const"
        }
    }

    // Find the parameter list boundaries
    auto openParen = d.find('(');
    auto closeParen = d.rfind(')');
    if (openParen == std::string::npos || closeParen == std::string::npos)
        return std::nullopt;

    std::string beforeParens = Trim(d.substr(0, openParen));
    std::string paramStr     = d.substr(openParen + 1, closeParen - openParen - 1);

    // Split return type and method name from beforeParens
    // Last whitespace-separated token (excluding *, &) is the name
    // e.g. "bool CreateUser" or "std::optional<User> GetUser"
    // Handle cases where the name is attached to a * or & from the return type
    {
        // Walk backwards from end of beforeParens to find the name token
        std::size_t nameEnd = beforeParens.size();
        while (nameEnd > 0 && (std::isspace(beforeParens[nameEnd - 1]) ||
               beforeParens[nameEnd - 1] == '*' || beforeParens[nameEnd - 1] == '&'))
            --nameEnd;

        std::size_t nameStart = nameEnd;
        while (nameStart > 0 && !std::isspace(beforeParens[nameStart - 1]) &&
               beforeParens[nameStart - 1] != '*' && beforeParens[nameStart - 1] != '&' &&
               beforeParens[nameStart - 1] != ':')
            --nameStart;

        // Handle scope resolution (Class::Method)
        if (nameStart > 1 && beforeParens[nameStart - 1] == ':' && beforeParens[nameStart - 2] == ':')
            return std::nullopt; // skip out-of-line definitions

        m.name = Trim(beforeParens.substr(nameStart, nameEnd - nameStart));
        if (m.name.empty()) return std::nullopt;

        std::string retPart = Trim(beforeParens.substr(0, nameStart));
        // Strip trailing * & from return type
        while (!retPart.empty() && (retPart.back() == '*' || retPart.back() == '&'))
        {
            m.returnType += retPart.back();
            retPart.pop_back();
        }
        std::reverse(m.returnType.begin(), m.returnType.end());
        m.returnType = Trim(retPart) + m.returnType;
        m.returnType = Trim(m.returnType);
    }

    if (m.name.empty()) return std::nullopt;

    // Detect constructor / destructor
    m.isDestructor  = (!m.name.empty() && m.name[0] == '~');
    m.isConstructor = (m.returnType.empty() && !m.isDestructor);
    if (m.isConstructor) m.returnType = "";

    // Parse parameters
    m.params = ParseParamList(paramStr);

    return m;
}

// =============================================================================
// Member variable parser
// =============================================================================

std::optional<MemberVar> ClassParser::ParseMemberVar(const std::string& decl)
{
    // Simple heuristic: last identifier before optional initialiser is the name
    std::string d = decl;
    // Strip array brackets: int arr[10] -> name is arr
    auto bracket = d.find('[');
    if (bracket != std::string::npos)
        d = d.substr(0, bracket);
    d = Trim(d);
    if (d.empty()) return std::nullopt;

    // Split by whitespace; last token = name (may have * prefix)
    std::istringstream ss(d);
    std::vector<std::string> tokens;
    std::string tok;
    while (ss >> tok) tokens.push_back(tok);
    if (tokens.size() < 2) return std::nullopt;

    MemberVar mv;
    mv.name = tokens.back();
    // Strip leading * from name
    while (!mv.name.empty() && (mv.name[0] == '*' || mv.name[0] == '&'))
        mv.name.erase(0, 1);

    mv.type = d.substr(0, d.rfind(tokens.back()));
    mv.type = Trim(mv.type);
    // Trailing * belongs to type
    if (!mv.type.empty() && mv.name[0] == '*')
        mv.type += "*";

    // Remove raw pointer/ref markers already folded into type
    // (They were handled above; ensure name is clean)
    if (mv.name.empty() || mv.type.empty()) return std::nullopt;

    return mv;
}

// =============================================================================
// Parameter list parser
// =============================================================================

std::vector<MethodParam> ClassParser::ParseParamList(const std::string& paramStr)
{
    std::vector<MethodParam> params;
    if (Trim(paramStr).empty() || Trim(paramStr) == "void") return params;

    // Split by commas (respecting angle brackets for templates)
    std::vector<std::string> parts;
    std::string current;
    int depth = 0;
    for (char c : paramStr)
    {
        if (c == '<' || c == '(') ++depth;
        else if (c == '>' || c == ')') { if (depth > 0) --depth; }
        if (c == ',' && depth == 0)
        {
            parts.push_back(Trim(current));
            current.clear();
        }
        else current += c;
    }
    if (!Trim(current).empty()) parts.push_back(Trim(current));

    for (auto& part : parts)
    {
        if (Trim(part).empty()) continue;

        // Strip default value
        auto eqPos = part.find('=');
        if (eqPos != std::string::npos) part = part.substr(0, eqPos);
        part = Trim(part);

        // Split type and name: last identifier is the name
        std::istringstream ss(part);
        std::vector<std::string> toks;
        std::string t;
        while (ss >> t) toks.push_back(t);

        MethodParam p;
        if (toks.empty()) continue;

        if (toks.size() == 1)
        {
            // Unnamed parameter
            p.type = toks[0];
            p.name = "param" + std::to_string(params.size() + 1);
        }
        else
        {
            p.name = toks.back();
            // Strip leading * from name into type
            while (!p.name.empty() && (p.name[0] == '*' || p.name[0] == '&'))
            {
                p.name.erase(0, 1);
            }
            p.type = part.substr(0, part.rfind(p.name));
            p.type = Trim(p.type);
        }

        // Sanitise name – if it ends up empty, manufacture one
        if (p.name.empty())
            p.name = "param" + std::to_string(params.size() + 1);

        params.push_back(p);
    }
    return params;
}

// =============================================================================
// Interface detection from constructor parameters
// =============================================================================

void ClassParser::ParseConstructorInterfaces(const ClassInfo& info, ClassInfo& out)
{
    // Find the constructor (if any) and extract pointer/reference params that look
    // like interfaces (name starts with 'I' followed by uppercase, or ends in 'Interface').
    for (auto& m : info.publicMethods)
    {
        if (!m.isConstructor) continue;

        for (auto& p : m.params)
        {
            std::string stripped = StripPointerRef(p.type);
            if (!LooksLikeInterface(stripped)) continue;

            // Avoid duplicates
            bool already = false;
            for (auto& iface : out.interfaces)
                if (iface.interfaceName == stripped) { already = true; break; }
            if (already) continue;

            InterfaceInfo iface;
            iface.rawType       = p.type;
            iface.interfaceName = stripped;
            iface.mockName      = DeriveMockName(stripped);
            iface.paramName     = p.name;
            out.interfaces.push_back(iface);
        }
    }
}

// =============================================================================
// Helpers
// =============================================================================

std::string ClassParser::Trim(const std::string& s)
{
    auto start = s.begin();
    while (start != s.end() && std::isspace(static_cast<unsigned char>(*start))) ++start;
    auto end = s.end();
    while (end != start && std::isspace(static_cast<unsigned char>(*(end - 1)))) --end;
    return { start, end };
}

std::string ClassParser::StripPointerRef(const std::string& type)
{
    std::string t = type;
    // Remove const, *, &, whitespace
    for (const char* kw : { "const ", " const", "*", "&" })
    {
        std::size_t pos;
        while ((pos = t.find(kw)) != std::string::npos)
            t.erase(pos, std::strlen(kw));
    }
    return Trim(t);
}

std::string ClassParser::DeriveInterfaceName(const std::string& rawType)
{
    return StripPointerRef(rawType);
}

std::string ClassParser::DeriveMockName(const std::string& interfaceName)
{
    return "Mock" + interfaceName;
}

std::string ClassParser::DeriveHeaderGuard(const std::string& className)
{
    std::string guard = className;
    std::transform(guard.begin(), guard.end(), guard.begin(), ::toupper);
    return guard;
}

bool ClassParser::IsBuiltinType(const std::string& type)
{
    static const std::set<std::string> builtins =
    {
        "int", "float", "double", "bool", "char", "long", "short",
        "unsigned", "signed", "void", "size_t", "uint8_t", "uint16_t",
        "uint32_t", "uint64_t", "int8_t", "int16_t", "int32_t", "int64_t",
        "std::string", "std::wstring", "std::vector", "std::map",
        "std::unordered_map", "std::optional", "std::unique_ptr",
        "std::shared_ptr", "std::weak_ptr", "std::function"
    };
    return builtins.count(type) > 0;
}

bool ClassParser::LooksLikeInterface(const std::string& type)
{
    if (type.empty()) return false;
    // Convention: starts with 'I' followed by upper-case letter  (e.g. ILogger, IDatabase)
    if (type.size() >= 2 && type[0] == 'I' && std::isupper(static_cast<unsigned char>(type[1])))
        return true;
    // Or ends with 'Interface'
    if (type.size() > 9 && type.substr(type.size() - 9) == "Interface")
        return true;
    return false;
}

} // namespace GTestGen
