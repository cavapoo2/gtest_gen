#pragma once
#include "GeneratorConfig.h"
#include <string>
#include <optional>

namespace GTestGen
{
    /// Parses a C++ class header file and populates a ClassInfo structure.
    ///
    /// Limitations (intentional – keeps the parser dependency-free):
    ///   - Single class per header.
    ///   - Does not handle template classes.
    ///   - Macros are not expanded; if the header uses heavy macros the parser
    ///     may miss some declarations.
    ///   - Nested classes are detected but not recursed into.
    class ClassParser
    {
    public:
        /// Parse the header at @p path.
        /// Returns std::nullopt and writes a message to stderr on failure.
        static std::optional<ClassInfo> Parse(const std::string& path, bool verbose = false);

        /// For each InterfaceInfo in @p info, search @p searchPaths for a header
        /// named <InterfaceName>.h and parse its public virtual methods into
        /// InterfaceInfo::methods.  The directory of the original input header is
        /// always searched first.
        static void ResolveInterfaces(ClassInfo& info,
                                      const std::vector<std::string>& searchPaths,
                                      bool verbose = false);

    private:
        // --- Text pre-processing ------------------------------------------------
        static std::string ReadFile(const std::string& path);
        static std::string StripComments(const std::string& src);
        static std::string StripPreprocessor(const std::string& src);

        // --- High-level parsing passes ------------------------------------------
        static std::optional<std::string> ExtractClassName(const std::string& src);
        static void ParseAccessSections(const std::string& classBody,
                                        ClassInfo& out);
        static void ParseConstructorInterfaces(const ClassInfo& info,
                                               ClassInfo& out);

        // --- Method / member parsers --------------------------------------------
        static std::optional<MethodInfo>  ParseMethodDecl(const std::string& decl,
                                                           bool isPrivate);
        static std::optional<MemberVar>   ParseMemberVar(const std::string& decl);
        static std::vector<MethodParam>   ParseParamList(const std::string& paramStr);

        // --- Helpers ------------------------------------------------------------
        static std::string Trim(const std::string& s);
        static std::string StripPointerRef(const std::string& type);
        static std::string DeriveInterfaceName(const std::string& rawType);
        static std::string DeriveMockName(const std::string& interfaceName);
        static std::string DeriveHeaderGuard(const std::string& className);
        static bool        IsBuiltinType(const std::string& type);
        static bool        LooksLikeInterface(const std::string& type);
    };

} // namespace GTestGen
