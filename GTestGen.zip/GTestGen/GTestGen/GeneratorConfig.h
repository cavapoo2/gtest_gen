#pragma once
#include <string>
#include <vector>

namespace GTestGen
{
    // -----------------------------------------------------------------------
    // Data model produced by ClassParser and consumed by TestGenerator
    // -----------------------------------------------------------------------

    struct MethodParam
    {
        std::string type;   // e.g. "const std::string&"
        std::string name;   // e.g. "userId"
    };

    // -----------------------------------------------------------------------
    // Branch analysis – produced by ImplParser from the .cpp file
    // -----------------------------------------------------------------------

    enum class BranchKind
    {
        IfCondition,    // if (x > 0)
        ElseClause,     // else / else-if – the "false" side of an if
        SwitchCase,     // case VALUE:
        DefaultCase,    // default:
        EarlyReturn,    // return <expr>; inside a branch
        TernaryTrue,    // true arm of condition ? a : b
        TernaryFalse,   // false arm of condition ? a : b
        LoopCondition,  // for/while/do-while guard
    };

    inline const char* BranchKindLabel(BranchKind k)
    {
        switch (k)
        {
        case BranchKind::IfCondition:   return "if";
        case BranchKind::ElseClause:    return "else";
        case BranchKind::SwitchCase:    return "case";
        case BranchKind::DefaultCase:   return "default";
        case BranchKind::EarlyReturn:   return "early-return";
        case BranchKind::TernaryTrue:   return "ternary-true";
        case BranchKind::TernaryFalse:  return "ternary-false";
        case BranchKind::LoopCondition: return "loop";
        default:                        return "branch";
        }
    }

    struct BranchHint
    {
        BranchKind  kind;
        int         lineNumber  = 0;    // source line in the .cpp (0 = unknown)
        std::string condition;          // raw text of the condition / case value
        std::string description;        // human-readable suggestion for a test row
    };

    struct MethodInfo
    {
        std::string        returnType;      // e.g. "bool", "std::optional<User>"
        std::string        name;            // e.g. "CreateUser"
        std::vector<MethodParam> params;
        bool               isConst      = false;
        bool               isVirtual    = false;
        bool               isPureVirtual= false;
        bool               isOverride   = false;
        bool               isPrivate    = false;   // true  => private method (via friend)
        bool               isConstructor= false;
        bool               isDestructor = false;

        // Populated by ImplParser (empty when no .cpp is provided)
        std::vector<BranchHint> branchHints;
    };

    struct MemberVar
    {
        std::string type;   // e.g. "ILogger*"
        std::string name;   // e.g. "m_logger"
    };

    /// An interface detected from the constructor parameters of the class under test.
    struct InterfaceInfo
    {
        std::string rawType;        // e.g. "ILogger*"
        std::string interfaceName;  // e.g. "ILogger"
        std::string mockName;       // e.g. "MockILogger"
        std::string paramName;      // as it appears in the ctor param list
    };

    struct ClassInfo
    {
        std::string               className;
        std::string               headerGuard;          // derived from className
        std::vector<MethodInfo>   publicMethods;
        std::vector<MethodInfo>   privateMethods;
        std::vector<MemberVar>    memberVars;
        std::vector<InterfaceInfo> interfaces;          // from ctor params
        std::vector<std::string>  existingIncludes;     // #include lines found in header
    };

    // -----------------------------------------------------------------------
    // Runtime configuration (populated from CLI arguments)
    // -----------------------------------------------------------------------

    struct GeneratorConfig
    {
        std::string inputHeaderPath;        // Path to the class header to parse
        std::string implSourcePath;         // Path to the .cpp implementation (optional)
        std::string outputDir;              // Directory to write generated files into
        std::string testNamespace;          // Optional namespace for generated tests
        bool        generateCMake = false;  // Emit CMakeLists.txt in addition to VS files
        bool        verbose       = false;
    };

} // namespace GTestGen
