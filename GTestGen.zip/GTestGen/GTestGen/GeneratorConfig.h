#pragma once
#include <string>
#include <vector>

namespace GTestGen
{
    // -----------------------------------------------------------------------
    // Data model produced by ClassParser and consumed by TestGenerator
    // -----------------------------------------------------------------------

    struct MethodParam
    {
        std::string type;   // e.g. "const std::string&"
        std::string name;   // e.g. "userId"
    };

    struct MethodInfo
    {
        std::string        returnType;      // e.g. "bool", "std::optional<User>"
        std::string        name;            // e.g. "CreateUser"
        std::vector<MethodParam> params;
        bool               isConst      = false;
        bool               isVirtual    = false;
        bool               isPureVirtual= false;
        bool               isOverride   = false;
        bool               isPrivate    = false;   // true  => private method (via friend)
        bool               isConstructor= false;
        bool               isDestructor = false;
    };

    struct MemberVar
    {
        std::string type;   // e.g. "ILogger*"
        std::string name;   // e.g. "m_logger"
    };

    /// An interface detected from the constructor parameters of the class under test.
    struct InterfaceInfo
    {
        std::string rawType;        // e.g. "ILogger*"
        std::string interfaceName;  // e.g. "ILogger"
        std::string mockName;       // e.g. "MockILogger"
        std::string paramName;      // as it appears in the ctor param list
    };

    struct ClassInfo
    {
        std::string               className;
        std::string               headerGuard;          // derived from className
        std::vector<MethodInfo>   publicMethods;
        std::vector<MethodInfo>   privateMethods;
        std::vector<MemberVar>    memberVars;
        std::vector<InterfaceInfo> interfaces;          // from ctor params
        std::vector<std::string>  existingIncludes;     // #include lines found in header
    };

    // -----------------------------------------------------------------------
    // Runtime configuration (populated from CLI arguments)
    // -----------------------------------------------------------------------

    struct GeneratorConfig
    {
        std::string inputHeaderPath;        // Path to the class header to parse
        std::string outputDir;              // Directory to write generated files into
        std::string testNamespace;          // Optional namespace for generated tests
        bool        generateCMake = false;  // Emit CMakeLists.txt in addition to VS files
        bool        verbose       = false;
    };

} // namespace GTestGen
