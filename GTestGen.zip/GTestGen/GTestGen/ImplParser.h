#pragma once
#include "GeneratorConfig.h"
#include <string>
#include <vector>

namespace GTestGen
{
    /// Parses the .cpp implementation file for a class and attaches BranchHint
    /// entries to the corresponding MethodInfo objects in @p methods.
    ///
    /// Strategy
    /// --------
    /// For each method body found (matched by "ClassName::MethodName("), the
    /// parser walks the body character-by-character (respecting brace depth and
    /// string/comment contexts) and applies lightweight pattern recognition for:
    ///
    ///   if / else if / else
    ///   switch / case / default
    ///   return <expr>;          (early return – any return inside a branch)
    ///   condition ? a : b       (ternary)
    ///   for / while / do        (loop guard)
    ///
    /// Results are human-readable suggestions attached to each MethodInfo so that
    /// TestGenerator can emit structured TODO comments in the generated test file.
    ///
    /// Limitations (intentional):
    ///   - Does not parse macro-expanded code.
    ///   - Nested lambdas are skipped (lambda bodies are consumed but not analysed).
    ///   - Template method bodies with complex angle-bracket nesting may be
    ///     partially mis-parsed; hints are best-effort.
    class ImplParser
    {
    public:
        /// Read @p implPath, locate each method body for @p className, and
        /// populate MethodInfo::branchHints for matching entries in @p methods.
        /// Returns false only on file I/O failure; partial results are retained.
        static bool Parse(const std::string& implPath,
                          const std::string& className,
                          std::vector<MethodInfo>& publicMethods,
                          std::vector<MethodInfo>& privateMethods,
                          bool verbose = false);

    private:
        // --- Text pre-processing ------------------------------------------------
        static std::string ReadFile(const std::string& path);
        static std::string StripCommentsAndStrings(const std::string& src,
                                                   std::vector<int>& lineMap);

        // --- Method-body extraction ---------------------------------------------
        struct MethodBody
        {
            std::string methodName;
            std::string body;           // text between the outermost { }
            int         startLine = 0;
        };

        static std::vector<MethodBody> ExtractMethodBodies(
                                            const std::string& src,
                                            const std::vector<int>& lineMap,
                                            const std::string& className);

        // --- Branch extraction --------------------------------------------------
        static std::vector<BranchHint> ExtractBranches(const std::string& body,
                                                        int bodyStartLine,
                                                        const std::vector<int>& lineMap);

        // --- Condition/expression extraction ------------------------------------
        /// Extract the content of the first balanced parenthesis pair after @p pos.
        static std::string ExtractParenthesised(const std::string& src, std::size_t pos);

        /// Extract the expression following a 'return' keyword up to ';'.
        static std::string ExtractReturnExpr(const std::string& src, std::size_t pos);

        /// Extract the case value after 'case' up to ':'.
        static std::string ExtractCaseValue(const std::string& src, std::size_t pos);

        // --- Description builders -----------------------------------------------
        static std::string MakeIfDescription   (const std::string& condition);
        static std::string MakeElseDescription (const std::string& condition);
        static std::string MakeCaseDescription (const std::string& value);
        static std::string MakeReturnDescription(const std::string& expr);
        static std::string MakeLoopDescription (const std::string& condition,
                                                const std::string& keyword);

        // --- Helpers ------------------------------------------------------------
        static std::string Trim(const std::string& s);
        static bool        IsWordBoundary(const std::string& src, std::size_t pos,
                                          std::size_t keywordLen);
    };

} // namespace GTestGen
