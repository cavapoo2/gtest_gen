#include "ImplParser.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <regex>
#include <algorithm>
#include <cassert>
#include <cctype>

namespace GTestGen
{

// =============================================================================
// Public entry point
// =============================================================================

bool ImplParser::Parse(const std::string&      implPath,
                       const std::string&      className,
                       std::vector<MethodInfo>& publicMethods,
                       std::vector<MethodInfo>& privateMethods,
                       bool                    verbose)
{
    std::string raw = ReadFile(implPath);
    if (raw.empty())
    {
        std::cerr << "[ImplParser] Cannot read file: " << implPath << "\n";
        return false;
    }

    // Build a stripped copy for parsing (no comments/strings) and a line map
    // so we can report source line numbers in hints.
    std::vector<int> lineMap;        // lineMap[charIndex] = 1-based line number
    std::string      clean = StripCommentsAndStrings(raw, lineMap);

    // Extract method bodies for this class
    auto bodies = ExtractMethodBodies(clean, lineMap, className);

    if (verbose)
        std::cout << "[ImplParser] Found " << bodies.size()
                  << " method body(ies) for class " << className << "\n";

    // For each body, find the matching MethodInfo and attach branch hints
    auto attachHints = [&](std::vector<MethodInfo>& methods)
    {
        for (auto& mi : methods)
        {
            if (mi.isConstructor || mi.isDestructor) continue;

            for (auto& mb : bodies)
            {
                if (mb.methodName != mi.name) continue;

                auto hints = ExtractBranches(mb.body, mb.startLine, lineMap);
                mi.branchHints.insert(mi.branchHints.end(),
                                      hints.begin(), hints.end());

                if (verbose)
                    std::cout << "[ImplParser]   " << mi.name
                              << " → " << hints.size() << " branch hint(s)\n";
            }
        }
    };

    attachHints(publicMethods);
    attachHints(privateMethods);

    return true;
}

// =============================================================================
// Text pre-processing
// =============================================================================

std::string ImplParser::ReadFile(const std::string& path)
{
    std::ifstream f(path);
    if (!f.is_open()) return {};
    return { std::istreambuf_iterator<char>(f),
             std::istreambuf_iterator<char>() };
}

/// Returns the stripped source and fills @p lineMap so that
/// lineMap[i] gives the original 1-based line number for character i
/// in the returned string.
std::string ImplParser::StripCommentsAndStrings(const std::string& src,
                                                 std::vector<int>&  lineMap)
{
    std::string out;
    out.reserve(src.size());
    lineMap.reserve(src.size());

    int  line  = 1;
    std::size_t i = 0;

    auto emit = [&](char c)
    {
        out      += c;
        lineMap  .push_back(line);
        if (c == '\n') ++line;
    };

    auto emitSpace = [&]()
    {
        // Emit a single space to preserve token boundaries
        out     += ' ';
        lineMap .push_back(line);
    };

    while (i < src.size())
    {
        // Block comment
        if (i + 1 < src.size() && src[i] == '/' && src[i + 1] == '*')
        {
            i += 2;
            while (i + 1 < src.size() && !(src[i] == '*' && src[i + 1] == '/'))
            {
                if (src[i] == '\n') { emit('\n'); ++i; }
                else ++i;
            }
            i += 2;
            emitSpace();
        }
        // Line comment
        else if (i + 1 < src.size() && src[i] == '/' && src[i + 1] == '/')
        {
            while (i < src.size() && src[i] != '\n') ++i;
            // newline itself is emitted below in the normal path
        }
        // String literal – replace with "" placeholder
        else if (src[i] == '"')
        {
            ++i;
            while (i < src.size() && src[i] != '"')
            {
                if (src[i] == '\\') ++i; // skip escape
                if (i < src.size() && src[i] == '\n') { emit('\n'); }
                ++i;
            }
            ++i; // closing "
            // Emit two placeholder chars so token boundaries are preserved
            emitSpace();
        }
        // Char literal
        else if (src[i] == '\'')
        {
            ++i;
            while (i < src.size() && src[i] != '\'')
            {
                if (src[i] == '\\') ++i;
                ++i;
            }
            ++i;
            emitSpace();
        }
        else
        {
            emit(src[i++]);
        }
    }

    return out;
}

// =============================================================================
// Method body extraction
// =============================================================================

std::vector<ImplParser::MethodBody>
ImplParser::ExtractMethodBodies(const std::string&    src,
                                 const std::vector<int>& lineMap,
                                 const std::string&    className)
{
    std::vector<MethodBody> result;

    // Match "ClassName::MethodName" followed by a parameter list and then '{'
    // We use a simple scan rather than a regex to handle angle brackets in
    // return types / template parameters correctly.

    const std::string prefix = className + "::";
    std::size_t       searchFrom = 0;

    while (searchFrom < src.size())
    {
        auto prefixPos = src.find(prefix, searchFrom);
        if (prefixPos == std::string::npos) break;

        // Check this is not inside an identifier (e.g. AnotherClassName::Foo)
        if (prefixPos > 0 && (std::isalnum(static_cast<unsigned char>(src[prefixPos - 1])) ||
                               src[prefixPos - 1] == '_'))
        {
            searchFrom = prefixPos + prefix.size();
            continue;
        }

        // Extract method name: identifier after "::"
        std::size_t nameStart = prefixPos + prefix.size();
        std::size_t nameEnd   = nameStart;
        while (nameEnd < src.size() &&
               (std::isalnum(static_cast<unsigned char>(src[nameEnd])) ||
                src[nameEnd] == '_'))
            ++nameEnd;

        if (nameEnd == nameStart)
        {
            searchFrom = nameEnd + 1;
            continue;
        }

        std::string methodName = src.substr(nameStart, nameEnd - nameStart);

        // Skip whitespace and find the opening '(' of the param list
        std::size_t parenPos = nameEnd;
        while (parenPos < src.size() && src[parenPos] != '(' && src[parenPos] != '\n')
            ++parenPos;

        if (parenPos >= src.size() || src[parenPos] != '(')
        {
            searchFrom = nameEnd + 1;
            continue;
        }

        // Balance parentheses to skip the parameter list
        int parenDepth = 0;
        std::size_t afterParams = parenPos;
        while (afterParams < src.size())
        {
            if      (src[afterParams] == '(') ++parenDepth;
            else if (src[afterParams] == ')') { --parenDepth; if (parenDepth == 0) { ++afterParams; break; } }
            ++afterParams;
        }

        // Skip const, noexcept, initialiser lists, whitespace until '{'
        std::size_t bracePos = afterParams;
        while (bracePos < src.size() && src[bracePos] != '{' && src[bracePos] != ';')
            ++bracePos;

        if (bracePos >= src.size() || src[bracePos] != '{')
        {
            // It's a declaration, not a definition
            searchFrom = afterParams;
            continue;
        }

        int startLine = (bracePos < lineMap.size()) ? lineMap[bracePos] : 0;

        // Balance braces to extract the body
        int         depth     = 0;
        std::size_t bodyStart = bracePos + 1;
        std::size_t bodyEnd   = bodyStart;
        bool        found     = false;

        for (std::size_t j = bracePos; j < src.size(); ++j)
        {
            if      (src[j] == '{') ++depth;
            else if (src[j] == '}')
            {
                --depth;
                if (depth == 0) { bodyEnd = j; found = true; break; }
            }
        }

        if (found)
        {
            MethodBody mb;
            mb.methodName = methodName;
            mb.body       = src.substr(bodyStart, bodyEnd - bodyStart);
            mb.startLine  = startLine;
            result.push_back(std::move(mb));
        }

        searchFrom = found ? bodyEnd + 1 : bracePos + 1;
    }

    return result;
}

// =============================================================================
// Branch extraction – the core analysis pass
// =============================================================================

std::vector<BranchHint>
ImplParser::ExtractBranches(const std::string&    body,
                              int                   bodyStartLine,
                              const std::vector<int>& /*lineMap*/)
{
    std::vector<BranchHint> hints;

    // We walk the body looking for keywords.  We track brace depth so we can
    // skip lambda bodies (depth > 1 from the method body's perspective means
    // we're inside a nested scope – we still analyse it, but lambdas are
    // identified by "[]" or "[&]" / "[=]" patterns preceding "{").

    // Helper: find keyword at word boundary
    auto findKeyword = [&](const std::string& kw, std::size_t from) -> std::size_t
    {
        std::size_t pos = from;
        while (pos < body.size())
        {
            pos = body.find(kw, pos);
            if (pos == std::string::npos) return std::string::npos;
            if (IsWordBoundary(body, pos, kw.size())) return pos;
            ++pos;
        }
        return std::string::npos;
    };

    // Collect all branch positions with their kinds, then sort by position
    struct RawBranch { std::size_t pos; BranchKind kind; std::string token; };
    std::vector<RawBranch> raw;

    // Scan for: if, else, switch, case, default, return, for, while, do, ?
    for (std::size_t i = 0; i < body.size(); )
    {
        char c = body[i];

        // Skip nested brace contents that belong to lambdas introduced by []
        // We detect "[ ... ]" just before "(" or "{".  Simple heuristic.
        if (c == '[')
        {
            // Might be a lambda capture; skip to next ] at same depth
            ++i;
            while (i < body.size() && body[i] != ']') ++i;
            if (i < body.size()) ++i;
            continue;
        }

        // Keyword scan
        if (std::isalpha(static_cast<unsigned char>(c)) || c == '_')
        {
            // Extract identifier
            std::size_t kStart = i;
            while (i < body.size() &&
                   (std::isalnum(static_cast<unsigned char>(body[i])) || body[i] == '_'))
                ++i;
            std::string kw = body.substr(kStart, i - kStart);

            if      (kw == "if")      raw.push_back({ kStart, BranchKind::IfCondition,  kw });
            else if (kw == "else")    raw.push_back({ kStart, BranchKind::ElseClause,   kw });
            else if (kw == "switch")  raw.push_back({ kStart, BranchKind::IfCondition,  kw }); // treated as if-group
            else if (kw == "case")    raw.push_back({ kStart, BranchKind::SwitchCase,   kw });
            else if (kw == "default") raw.push_back({ kStart, BranchKind::DefaultCase,  kw });
            else if (kw == "return")  raw.push_back({ kStart, BranchKind::EarlyReturn,  kw });
            else if (kw == "for")     raw.push_back({ kStart, BranchKind::LoopCondition,kw });
            else if (kw == "while")   raw.push_back({ kStart, BranchKind::LoopCondition,kw });
            else if (kw == "do")      raw.push_back({ kStart, BranchKind::LoopCondition,kw });
            continue;
        }

        // Ternary operator
        if (c == '?')
        {
            raw.push_back({ i, BranchKind::TernaryTrue,  "?" });
        }

        ++i;
    }

    // ---- Now produce BranchHints from raw entries ---------------------------

    // Track how many 'if' conditions we've seen so we can label
    // the corresponding else as "else of condition N".
    std::vector<std::string> ifConditionStack;

    for (auto& rb : raw)
    {
        BranchHint hint;
        hint.kind       = rb.kind;
        hint.lineNumber = bodyStartLine; // approximate; we don't have per-char line numbers here

        switch (rb.kind)
        {
        case BranchKind::IfCondition:
        {
            // "if" or "switch"
            bool isSwitch = (rb.token == "switch");
            std::string cond = ExtractParenthesised(body, rb.pos + rb.token.size());
            hint.condition   = cond;
            hint.kind        = BranchKind::IfCondition;
            hint.description = isSwitch
                ? MakeIfDescription("switch (" + cond + ")")
                : MakeIfDescription(cond);
            ifConditionStack.push_back(cond);
            hints.push_back(hint);

            // For 'if', also emit the implicit else / false path
            if (!isSwitch)
            {
                BranchHint elsHint;
                elsHint.kind        = BranchKind::ElseClause;
                elsHint.lineNumber  = hint.lineNumber;
                elsHint.condition   = cond;
                elsHint.description = MakeElseDescription(cond);
                hints.push_back(elsHint);
            }
            break;
        }

        case BranchKind::ElseClause:
        {
            // Explicit 'else' in source; check if followed by 'if'
            std::size_t after = rb.pos + 4; // skip "else"
            while (after < body.size() && std::isspace(static_cast<unsigned char>(body[after])))
                ++after;

            bool isElseIf = (after + 2 <= body.size() && body.substr(after, 2) == "if");
            if (isElseIf)
            {
                // Already captured by the subsequent IfCondition entry; skip
                break;
            }
            // Pure else – already emitted the false-path hint above; skip duplicate
            break;
        }

        case BranchKind::SwitchCase:
        {
            std::string val = ExtractCaseValue(body, rb.pos + 4); // skip "case"
            hint.condition   = val;
            hint.description = MakeCaseDescription(val);
            hints.push_back(hint);
            break;
        }

        case BranchKind::DefaultCase:
        {
            hint.condition   = "default";
            hint.description = "Drive execution to the default: case";
            hints.push_back(hint);
            break;
        }

        case BranchKind::EarlyReturn:
        {
            std::string expr = ExtractReturnExpr(body, rb.pos + 6); // skip "return"
            hint.condition   = expr;
            hint.description = MakeReturnDescription(expr);
            hints.push_back(hint);
            break;
        }

        case BranchKind::TernaryTrue:
        {
            // Walk backwards to find the condition before '?'
            std::size_t condEnd = rb.pos;
            while (condEnd > 0 && std::isspace(static_cast<unsigned char>(body[condEnd - 1])))
                --condEnd;
            // Find the start of the condition expression (heuristic: back to previous ';', '{', '(', or '\n')
            std::size_t condStart = condEnd;
            while (condStart > 0 &&
                   body[condStart - 1] != ';' && body[condStart - 1] != '{' &&
                   body[condStart - 1] != '(' && body[condStart - 1] != '\n')
                --condStart;

            std::string cond = Trim(body.substr(condStart, condEnd - condStart));
            hint.condition   = cond;
            hint.description = "Evaluate ternary condition true: (" + cond + ") is truthy";
            hints.push_back(hint);

            BranchHint falseHint;
            falseHint.kind        = BranchKind::TernaryFalse;
            falseHint.lineNumber  = hint.lineNumber;
            falseHint.condition   = cond;
            falseHint.description = "Evaluate ternary condition false: (" + cond + ") is falsy";
            hints.push_back(falseHint);
            break;
        }

        case BranchKind::LoopCondition:
        {
            std::string cond = ExtractParenthesised(body, rb.pos + rb.token.size());
            hint.condition   = cond;
            hint.description = MakeLoopDescription(cond, rb.token);
            hints.push_back(hint);

            // Also want the "loop never executes" case
            BranchHint skipHint;
            skipHint.kind        = BranchKind::ElseClause;
            skipHint.lineNumber  = hint.lineNumber;
            skipHint.condition   = cond;
            skipHint.description = "Drive '" + rb.token + " (" + cond + ")' to execute zero iterations";
            hints.push_back(skipHint);
            break;
        }

        default:
            break;
        }
    }

    return hints;
}

// =============================================================================
// Condition / expression extraction helpers
// =============================================================================

std::string ImplParser::ExtractParenthesised(const std::string& src, std::size_t pos)
{
    // Skip whitespace then find '('
    while (pos < src.size() && std::isspace(static_cast<unsigned char>(src[pos]))) ++pos;
    if (pos >= src.size() || src[pos] != '(') return "";

    ++pos; // skip '('
    int         depth = 1;
    std::size_t start = pos;

    while (pos < src.size() && depth > 0)
    {
        if      (src[pos] == '(') ++depth;
        else if (src[pos] == ')') --depth;
        ++pos;
    }

    std::string raw = src.substr(start, pos - start - 1);
    return Trim(raw);
}

std::string ImplParser::ExtractReturnExpr(const std::string& src, std::size_t pos)
{
    while (pos < src.size() && std::isspace(static_cast<unsigned char>(src[pos]))) ++pos;

    std::size_t start = pos;
    int         parenDepth = 0;

    while (pos < src.size())
    {
        char c = src[pos];
        if (c == '(') ++parenDepth;
        if (c == ')') --parenDepth;
        if (c == ';' && parenDepth == 0) break;
        ++pos;
    }

    std::string raw = src.substr(start, pos - start);
    return Trim(raw);
}

std::string ImplParser::ExtractCaseValue(const std::string& src, std::size_t pos)
{
    while (pos < src.size() && std::isspace(static_cast<unsigned char>(src[pos]))) ++pos;

    std::size_t start = pos;
    while (pos < src.size() && src[pos] != ':' && src[pos] != '\n') ++pos;

    return Trim(src.substr(start, pos - start));
}

// =============================================================================
// Description builders
// =============================================================================

std::string ImplParser::MakeIfDescription(const std::string& condition)
{
    return "Drive branch TRUE:  if (" + condition + ")";
}

std::string ImplParser::MakeElseDescription(const std::string& condition)
{
    return "Drive branch FALSE: if (" + condition + ") → else path";
}

std::string ImplParser::MakeCaseDescription(const std::string& value)
{
    return "Drive switch to case " + value;
}

std::string ImplParser::MakeReturnDescription(const std::string& expr)
{
    if (expr.empty() || expr == "void")
        return "Trigger early return (void)";
    return "Trigger early return with: " + expr;
}

std::string ImplParser::MakeLoopDescription(const std::string& condition,
                                              const std::string& keyword)
{
    return "Drive '" + keyword + " (" + condition + ")' to execute ≥1 iteration(s)";
}

// =============================================================================
// Helpers
// =============================================================================

std::string ImplParser::Trim(const std::string& s)
{
    auto start = s.begin();
    while (start != s.end() && std::isspace(static_cast<unsigned char>(*start))) ++start;
    auto end = s.end();
    while (end != start && std::isspace(static_cast<unsigned char>(*(end - 1)))) --end;
    // Collapse internal runs of whitespace / newlines to single space
    std::string result;
    result.reserve(static_cast<std::size_t>(end - start));
    bool prevSpace = false;
    for (auto it = start; it != end; ++it)
    {
        if (std::isspace(static_cast<unsigned char>(*it)))
        {
            if (!prevSpace) result += ' ';
            prevSpace = true;
        }
        else
        {
            result += *it;
            prevSpace = false;
        }
    }
    return result;
}

bool ImplParser::IsWordBoundary(const std::string& src, std::size_t pos,
                                 std::size_t keywordLen)
{
    // Check character before
    if (pos > 0)
    {
        char before = src[pos - 1];
        if (std::isalnum(static_cast<unsigned char>(before)) || before == '_')
            return false;
    }
    // Check character after
    std::size_t afterPos = pos + keywordLen;
    if (afterPos < src.size())
    {
        char after = src[afterPos];
        if (std::isalnum(static_cast<unsigned char>(after)) || after == '_')
            return false;
    }
    return true;
}

} // namespace GTestGen
