#pragma once
#include <string>
#include <map>
#include <functional>
#include <sstream>

namespace GTestGen
{
    /// Minimal template engine: replaces {{KEY}} tokens in a template string.
    class TemplateEngine
    {
    public:
        using VarMap = std::map<std::string, std::string>;

        /// Replace all {{KEY}} occurrences in @p tmpl using @p vars.
        static std::string Render(const std::string& tmpl, const VarMap& vars)
        {
            std::string result;
            result.reserve(tmpl.size());
            std::size_t i = 0;
            while (i < tmpl.size())
            {
                if (i + 1 < tmpl.size() && tmpl[i] == '{' && tmpl[i + 1] == '{')
                {
                    auto close = tmpl.find("}}", i + 2);
                    if (close != std::string::npos)
                    {
                        std::string key = tmpl.substr(i + 2, close - i - 2);
                        auto it = vars.find(key);
                        result += (it != vars.end()) ? it->second : ("{{" + key + "}}");
                        i = close + 2;
                        continue;
                    }
                }
                result += tmpl[i++];
            }
            return result;
        }

        /// Join a collection of strings with a separator.
        static std::string Join(const std::vector<std::string>& parts,
                                const std::string& sep = "\n")
        {
            std::ostringstream ss;
            for (std::size_t i = 0; i < parts.size(); ++i)
            {
                if (i > 0) ss << sep;
                ss << parts[i];
            }
            return ss.str();
        }

        /// Repeat @p str @p n times.
        static std::string Repeat(const std::string& str, int n)
        {
            std::string out;
            for (int i = 0; i < n; ++i) out += str;
            return out;
        }
    };

} // namespace GTestGen
