#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "ClassParser.h"
#include "TestGenerator.h"
#include <filesystem>
#include <fstream>
#include <string>

using namespace GTestGen;
using ::testing::HasSubstr;
using ::testing::Not;

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
namespace
{
    std::string FixturePath(const std::string& name)
    {
        fs::path here = fs::path(__FILE__).parent_path();
        return (here / "fixtures" / name).string();
    }

    std::string ReadFile(const fs::path& p)
    {
        std::ifstream f(p);
        return { std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>() };
    }

    // Parse + generate into a temp directory; return (outDir, success)
    std::pair<fs::path, bool> RunGenerator(const std::string& headerName,
                                            bool cmake = false)
    {
        auto info = ClassParser::Parse(FixturePath(headerName));
        if (!info) return { {}, false };

        fs::path outDir = fs::temp_directory_path()
                         / ("GTestGen_test_" + info->className);
        fs::remove_all(outDir);

        GeneratorConfig cfg;
        cfg.inputHeaderPath = FixturePath(headerName);
        cfg.outputDir       = outDir.string();
        cfg.generateCMake   = cmake;
        cfg.verbose         = false;

        bool ok = TestGenerator::Generate(*info, cfg);
        return { outDir, ok };
    }
}

// ===========================================================================
// Generator integration tests – SimpleClass
// ===========================================================================

class GeneratorSimpleClassTest : public ::testing::Test
{
protected:
    fs::path outDir;

    void SetUp() override
    {
        auto [dir, ok] = RunGenerator("SimpleClass.h");
        ASSERT_TRUE(ok) << "TestGenerator::Generate returned false";
        outDir = dir;
    }

    void TearDown() override
    {
        fs::remove_all(outDir);
    }

    std::string MockHeader()    { return ReadFile(outDir / "MockInterfaces.h"); }
    std::string FixtureHeader() { return ReadFile(outDir / "SimpleClassTestFixture.h"); }
    std::string TestsCpp()      { return ReadFile(outDir / "SimpleClassTests.cpp"); }
};

TEST_F(GeneratorSimpleClassTest, MockHeaderContainsMockILogger)
{
    EXPECT_THAT(MockHeader(), HasSubstr("MockILogger"));
}

TEST_F(GeneratorSimpleClassTest, MockHeaderIncludesGMock)
{
    EXPECT_THAT(MockHeader(), HasSubstr("#include <gmock/gmock.h>"));
}

TEST_F(GeneratorSimpleClassTest, FixtureIsFriendComment)
{
    // Must contain the friend declaration instruction
    EXPECT_THAT(FixtureHeader(), HasSubstr("friend class SimpleClassTests"));
}

TEST_F(GeneratorSimpleClassTest, FixtureExtendsTestWithParam)
{
    EXPECT_THAT(FixtureHeader(), HasSubstr("::testing::TestWithParam"));
}

TEST_F(GeneratorSimpleClassTest, FixtureHasSetUpAndTearDown)
{
    EXPECT_THAT(FixtureHeader(), HasSubstr("void SetUp()"));
    EXPECT_THAT(FixtureHeader(), HasSubstr("void TearDown()"));
}

TEST_F(GeneratorSimpleClassTest, FixtureHasPrivateHelper_ValidateInput)
{
    // The private method ValidateInput should have a Call_ helper
    EXPECT_THAT(FixtureHeader(), HasSubstr("Call_ValidateInput"));
}

TEST_F(GeneratorSimpleClassTest, TestsCppContainsTestForDoWork)
{
    EXPECT_THAT(TestsCpp(), HasSubstr("Public_DoWork"));
}

TEST_F(GeneratorSimpleClassTest, TestsCppContainsTestForGetCount)
{
    EXPECT_THAT(TestsCpp(), HasSubstr("Public_GetCount"));
}

TEST_F(GeneratorSimpleClassTest, TestsCppContainsTestForReset)
{
    EXPECT_THAT(TestsCpp(), HasSubstr("Public_Reset"));
}

TEST_F(GeneratorSimpleClassTest, TestsCppContainsPrivateTest)
{
    EXPECT_THAT(TestsCpp(), HasSubstr("Private_ValidateInput"));
}

TEST_F(GeneratorSimpleClassTest, TestsCppContainsInstantiateMacro)
{
    EXPECT_THAT(TestsCpp(), HasSubstr("INSTANTIATE_TEST_SUITE_P"));
}

TEST_F(GeneratorSimpleClassTest, TestsCppContainsThreeParamSets)
{
    EXPECT_THAT(TestsCpp(), HasSubstr("HappyPath"));
    EXPECT_THAT(TestsCpp(), HasSubstr("EdgeCase"));
    EXPECT_THAT(TestsCpp(), HasSubstr("NegativeCase"));
}

// ===========================================================================
// Generator integration tests – MultiInterfaceClass
// ===========================================================================

class GeneratorMultiInterfaceTest : public ::testing::Test
{
protected:
    fs::path outDir;

    void SetUp() override
    {
        auto [dir, ok] = RunGenerator("MultiInterfaceClass.h", /*cmake=*/true);
        ASSERT_TRUE(ok);
        outDir = dir;
    }

    void TearDown() override { fs::remove_all(outDir); }

    std::string MockHeader()    { return ReadFile(outDir / "MockInterfaces.h"); }
    std::string FixtureHeader() { return ReadFile(outDir / "DataServiceTestFixture.h"); }
    std::string TestsCpp()      { return ReadFile(outDir / "DataServiceTests.cpp"); }
    std::string CMake()         { return ReadFile(outDir / "CMakeLists.txt"); }
};

TEST_F(GeneratorMultiInterfaceTest, AllThreeMocksPresent)
{
    EXPECT_THAT(MockHeader(), HasSubstr("MockILogger"));
    EXPECT_THAT(MockHeader(), HasSubstr("MockIDatabase"));
    EXPECT_THAT(MockHeader(), HasSubstr("MockINetworkClient"));
}

TEST_F(GeneratorMultiInterfaceTest, FixtureHasAllThreeMockMembers)
{
    EXPECT_THAT(FixtureHeader(), HasSubstr("m_mockLogger"));
    EXPECT_THAT(FixtureHeader(), HasSubstr("m_mockDatabase"));
    EXPECT_THAT(FixtureHeader(), HasSubstr("m_mockNetworkClient"));
}

TEST_F(GeneratorMultiInterfaceTest, BothPrivateHelpersPresent)
{
    EXPECT_THAT(FixtureHeader(), HasSubstr("Call_IsKeyValid"));
    EXPECT_THAT(FixtureHeader(), HasSubstr("Call_BuildCacheKey"));
}

TEST_F(GeneratorMultiInterfaceTest, CMakeFileGenerated)
{
    EXPECT_THAT(CMake(), HasSubstr("cmake_minimum_required"));
    EXPECT_THAT(CMake(), HasSubstr("DataServiceTests"));
    EXPECT_THAT(CMake(), HasSubstr("GTest::gtest_main"));
    EXPECT_THAT(CMake(), HasSubstr("GTest::gmock"));
}

// ===========================================================================
// Parameterised: expected strings in generated fixtures
// ===========================================================================

struct GeneratedContentCheck
{
    std::string description;
    std::string headerName;
    std::string file;          // "mock" | "fixture" | "tests"
    std::string expectedToken;
};

class GeneratorContentTest : public ::testing::TestWithParam<GeneratedContentCheck>
{
protected:
    fs::path outDir;

    void SetUp() override
    {
        auto [dir, ok] = RunGenerator(GetParam().headerName);
        ASSERT_TRUE(ok);
        outDir = dir;
    }

    void TearDown() override { fs::remove_all(outDir); }
};

TEST_P(GeneratorContentTest, ContentPresent)
{
    const auto& p = GetParam();

    fs::path filePath;
    if (p.file == "mock")
        filePath = outDir / "MockInterfaces.h";
    else if (p.file == "fixture")
    {
        // Derive fixture name from class name
        auto info = ClassParser::Parse(FixturePath(p.headerName));
        ASSERT_TRUE(info.has_value());
        filePath = outDir / (info->className + "TestFixture.h");
    }
    else
    {
        auto info = ClassParser::Parse(FixturePath(p.headerName));
        ASSERT_TRUE(info.has_value());
        filePath = outDir / (info->className + "Tests.cpp");
    }

    std::string content = ReadFile(filePath);
    EXPECT_THAT(content, HasSubstr(p.expectedToken))
        << "Token not found in " << filePath.filename().string();
}

INSTANTIATE_TEST_SUITE_P(
    GeneratedContent,
    GeneratorContentTest,
    ::testing::Values(
        GeneratedContentCheck{ "MockILogger_in_mock",         "SimpleClass.h", "mock",    "MockILogger"              },
        GeneratedContentCheck{ "GMock_include_in_mock",       "SimpleClass.h", "mock",    "#include <gmock/gmock.h>" },
        GeneratedContentCheck{ "ParamStruct_in_fixture",      "SimpleClass.h", "fixture", "SimpleClassTestParams"    },
        GeneratedContentCheck{ "FriendDecl_in_fixture",       "SimpleClass.h", "fixture", "friend class SimpleClassTests" },
        GeneratedContentCheck{ "PrivateHelper_in_fixture",    "SimpleClass.h", "fixture", "Call_ValidateInput"       },
        GeneratedContentCheck{ "PublicTest_DoWork",           "SimpleClass.h", "tests",   "Public_DoWork"            },
        GeneratedContentCheck{ "PrivateTest_ValidateInput",   "SimpleClass.h", "tests",   "Private_ValidateInput"    },
        GeneratedContentCheck{ "EXPECT_CALL_comment",         "SimpleClass.h", "tests",   "EXPECT_CALL"              },
        GeneratedContentCheck{ "InstantiateMacro",            "SimpleClass.h", "tests",   "INSTANTIATE_TEST_SUITE_P" }
    ),
    [](const ::testing::TestParamInfo<GeneratorContentTest::ParamType>& i)
    {
        return i.param.description;
    }
);
