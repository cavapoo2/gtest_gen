// Test fixture implementation – used by ImplParserTests as parser input.
// This is NOT a real production file; it exists only so the ImplParser has
// something concrete to analyse during automated testing.

#include "SimpleClass.h"
#include <stdexcept>

SimpleClass::SimpleClass(ILogger* logger)
    : m_logger(logger)
    , m_count(0)
{
}

SimpleClass::~SimpleClass() = default;

bool SimpleClass::DoWork(int value)
{
    if (!ValidateInput(value))
    {
        m_logger->Log("Invalid input");
        return false;
    }

    if (value > 100)
    {
        m_count += 10;
    }
    else if (value > 0)
    {
        m_count += value;
    }
    else
    {
        m_logger->Log("Zero value");
    }

    return true;
}

int SimpleClass::GetCount() const
{
    return m_count;
}

void SimpleClass::Reset()
{
    m_count = 0;
    m_logger->Log("Reset");
}

bool SimpleClass::ValidateInput(int value)
{
    if (value < 0)
        return false;

    if (value > 1000)
        return false;

    return true;
}
