#pragma once
#include "ILogger.h"
#include "IDatabase.h"
#include "INetworkClient.h"

// Multi-dependency class used for generator integration tests.
class DataService
{
public:
    DataService(ILogger* logger, IDatabase* db, INetworkClient* net);
    ~DataService();

    bool  FetchAndStore(const std::string& key);
    bool  Delete(const std::string& key);
    std::string Query(const std::string& key) const;

private:
    bool  IsKeyValid(const std::string& key);
    std::string BuildCacheKey(const std::string& key);

    ILogger*       m_logger;
    IDatabase*     m_db;
    INetworkClient* m_net;
    int            m_cacheSize;
};
