#pragma once
#include "ILogger.h"

// Minimal class used as parser/generator test input.
// No real implementation exists; the file is only parsed for structure.
class SimpleClass
{
public:
    SimpleClass(ILogger* logger);
    ~SimpleClass();

    bool  DoWork(int value);
    int   GetCount() const;
    void  Reset();

private:
    bool  ValidateInput(int value);

    ILogger* m_logger;
    int      m_count;
};
