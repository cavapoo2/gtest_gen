#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "ClassParser.h"
#include <filesystem>
#include <string>

using namespace GTestGen;
using ::testing::SizeIs;
using ::testing::IsEmpty;
using ::testing::Not;

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
namespace
{
    // Resolve fixture paths relative to this source file's directory.
    // At runtime the test binary is in bin\x64\Debug(Release); we walk up to
    // find the solution root, then into GTestGenTests\fixtures.
    std::string FixturesDir()
    {
        // Use __FILE__ at compile time for a robust path.
        fs::path here = fs::path(__FILE__).parent_path();
        return (here / "fixtures").string();
    }

    std::string FixturePath(const std::string& name)
    {
        return (fs::path(FixturesDir()) / name).string();
    }
}

// ===========================================================================
// Parser smoke tests – SimpleClass.h
// ===========================================================================

class ParserSimpleClassTest : public ::testing::Test
{
protected:
    std::optional<ClassInfo> m_info;

    void SetUp() override
    {
        m_info = ClassParser::Parse(FixturePath("SimpleClass.h"));
        ASSERT_TRUE(m_info.has_value()) << "ClassParser::Parse returned nullopt";
    }
};

TEST_F(ParserSimpleClassTest, CorrectClassName)
{
    EXPECT_EQ(m_info->className, "SimpleClass");
}

TEST_F(ParserSimpleClassTest, DetectsPublicMethods)
{
    // Expected: DoWork, GetCount, Reset  (constructor and destructor may also appear)
    auto hasMethod = [&](const std::string& name)
    {
        return std::any_of(m_info->publicMethods.begin(), m_info->publicMethods.end(),
                           [&](const MethodInfo& m) { return m.name == name; });
    };
    EXPECT_TRUE(hasMethod("DoWork"));
    EXPECT_TRUE(hasMethod("GetCount"));
    EXPECT_TRUE(hasMethod("Reset"));
}

TEST_F(ParserSimpleClassTest, DetectsPrivateMethods)
{
    auto hasPrivate = [&](const std::string& name)
    {
        return std::any_of(m_info->privateMethods.begin(), m_info->privateMethods.end(),
                           [&](const MethodInfo& m) { return m.name == name; });
    };
    EXPECT_TRUE(hasPrivate("ValidateInput"));
}

TEST_F(ParserSimpleClassTest, DetectsILoggerInterface)
{
    ASSERT_THAT(m_info->interfaces, SizeIs(1));
    EXPECT_EQ(m_info->interfaces[0].interfaceName, "ILogger");
    EXPECT_EQ(m_info->interfaces[0].mockName, "MockILogger");
}

TEST_F(ParserSimpleClassTest, GetCountIsConst)
{
    auto it = std::find_if(m_info->publicMethods.begin(), m_info->publicMethods.end(),
                            [](const MethodInfo& m) { return m.name == "GetCount"; });
    ASSERT_NE(it, m_info->publicMethods.end());
    EXPECT_TRUE(it->isConst);
}

TEST_F(ParserSimpleClassTest, DoWorkHasOneParam)
{
    auto it = std::find_if(m_info->publicMethods.begin(), m_info->publicMethods.end(),
                            [](const MethodInfo& m) { return m.name == "DoWork"; });
    ASSERT_NE(it, m_info->publicMethods.end());
    ASSERT_THAT(it->params, SizeIs(1));
    EXPECT_EQ(it->params[0].type, "int");
}

// ===========================================================================
// Parser tests – MultiInterfaceClass.h
// ===========================================================================

class ParserMultiInterfaceTest : public ::testing::Test
{
protected:
    std::optional<ClassInfo> m_info;

    void SetUp() override
    {
        m_info = ClassParser::Parse(FixturePath("MultiInterfaceClass.h"));
        ASSERT_TRUE(m_info.has_value());
    }
};

TEST_F(ParserMultiInterfaceTest, ClassName)
{
    EXPECT_EQ(m_info->className, "DataService");
}

TEST_F(ParserMultiInterfaceTest, ThreeInterfacesDetected)
{
    EXPECT_THAT(m_info->interfaces, SizeIs(3));
}

TEST_F(ParserMultiInterfaceTest, InterfaceNamesCorrect)
{
    std::vector<std::string> names;
    for (auto& iface : m_info->interfaces)
        names.push_back(iface.interfaceName);

    EXPECT_THAT(names, ::testing::UnorderedElementsAre("ILogger", "IDatabase", "INetworkClient"));
}

TEST_F(ParserMultiInterfaceTest, MockNamesHaveMockPrefix)
{
    for (auto& iface : m_info->interfaces)
    {
        EXPECT_EQ(iface.mockName.substr(0, 4), "Mock")
            << "Mock name for " << iface.interfaceName << " should start with Mock";
    }
}

TEST_F(ParserMultiInterfaceTest, TwoPrivateMethods)
{
    // IsKeyValid and BuildCacheKey
    EXPECT_THAT(m_info->privateMethods, SizeIs(2));
}

// ===========================================================================
// Edge cases
// ===========================================================================

TEST(ParserEdgeCases, NonExistentFileReturnsNullopt)
{
    auto result = ClassParser::Parse("does_not_exist_xyz.h");
    EXPECT_FALSE(result.has_value());
}

// ---------------------------------------------------------------------------
// Parameterised: return-type parsing
// ---------------------------------------------------------------------------
struct ReturnTypeFixture
{
    std::string className;
    std::string methodName;
    std::string expectedReturnType;
};

class ParserReturnTypeTest : public ::testing::TestWithParam<ReturnTypeFixture> {};

TEST_P(ParserReturnTypeTest, ReturnTypeCorrectlyParsed)
{
    const auto& p = GetParam();
    auto info = ClassParser::Parse(FixturePath(p.className + ".h"));
    ASSERT_TRUE(info.has_value());

    auto it = std::find_if(info->publicMethods.begin(), info->publicMethods.end(),
                            [&](const MethodInfo& m){ return m.name == p.methodName; });
    ASSERT_NE(it, info->publicMethods.end())
        << "Method " << p.methodName << " not found in " << p.className;
    EXPECT_EQ(it->returnType, p.expectedReturnType);
}

INSTANTIATE_TEST_SUITE_P(
    ReturnTypes,
    ParserReturnTypeTest,
    ::testing::Values(
        ReturnTypeFixture{ "SimpleClass", "DoWork",   "bool" },
        ReturnTypeFixture{ "SimpleClass", "GetCount", "int"  },
        ReturnTypeFixture{ "SimpleClass", "Reset",    "void" }
    ),
    [](const ::testing::TestParamInfo<ParserReturnTypeTest::ParamType>& i)
    {
        return i.param.className + "_" + i.param.methodName;
    }
);
