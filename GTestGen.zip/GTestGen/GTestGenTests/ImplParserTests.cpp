#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "ImplParser.h"
#include "ClassParser.h"
#include <filesystem>
#include <algorithm>

using namespace GTestGen;
using ::testing::IsEmpty;
using ::testing::Not;
using ::testing::SizeIs;
using ::testing::Gt;

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
namespace
{
    std::string FixturePath(const std::string& name)
    {
        fs::path here = fs::path(__FILE__).parent_path();
        return (here / "fixtures" / name).string();
    }

    bool HasBranchKind(const std::vector<BranchHint>& hints, BranchKind kind)
    {
        return std::any_of(hints.begin(), hints.end(),
                           [kind](const BranchHint& h) { return h.kind == kind; });
    }

    bool AnyDescriptionContains(const std::vector<BranchHint>& hints,
                                const std::string& substr)
    {
        return std::any_of(hints.begin(), hints.end(),
                           [&](const BranchHint& h)
                           { return h.description.find(substr) != std::string::npos; });
    }

    // Parse the header, then run ImplParser on the .cpp, returning the enriched methods.
    struct EnrichedMethods
    {
        std::vector<MethodInfo> publicMethods;
        std::vector<MethodInfo> privateMethods;
        bool parseOk  = false;
        bool implOk   = false;
    };

    EnrichedMethods RunImplParser(const std::string& headerName,
                                  const std::string& implName)
    {
        EnrichedMethods result;
        auto info = ClassParser::Parse(FixturePath(headerName));
        if (!info) return result;
        result.parseOk       = true;
        result.publicMethods  = info->publicMethods;
        result.privateMethods = info->privateMethods;

        result.implOk = ImplParser::Parse(
            FixturePath(implName),
            info->className,
            result.publicMethods,
            result.privateMethods,
            /*verbose=*/false);

        return result;
    }
}

// ===========================================================================
// Smoke tests – SimpleClass
// ===========================================================================

class ImplParserSimpleClassTest : public ::testing::Test
{
protected:
    EnrichedMethods m_em;

    void SetUp() override
    {
        m_em = RunImplParser("SimpleClass.h", "SimpleClass.cpp");
        ASSERT_TRUE(m_em.parseOk)  << "ClassParser failed";
        ASSERT_TRUE(m_em.implOk)   << "ImplParser failed";
    }

    const MethodInfo* FindPublic(const std::string& name) const
    {
        for (auto& m : m_em.publicMethods)
            if (m.name == name) return &m;
        return nullptr;
    }

    const MethodInfo* FindPrivate(const std::string& name) const
    {
        for (auto& m : m_em.privateMethods)
            if (m.name == name) return &m;
        return nullptr;
    }
};

TEST_F(ImplParserSimpleClassTest, DoWork_HasBranchHints)
{
    auto* m = FindPublic("DoWork");
    ASSERT_NE(m, nullptr);
    EXPECT_THAT(m->branchHints, Not(IsEmpty()));
}

TEST_F(ImplParserSimpleClassTest, DoWork_HasIfBranch)
{
    auto* m = FindPublic("DoWork");
    ASSERT_NE(m, nullptr);
    EXPECT_TRUE(HasBranchKind(m->branchHints, BranchKind::IfCondition));
}

TEST_F(ImplParserSimpleClassTest, DoWork_HasElseBranch)
{
    auto* m = FindPublic("DoWork");
    ASSERT_NE(m, nullptr);
    EXPECT_TRUE(HasBranchKind(m->branchHints, BranchKind::ElseClause));
}

TEST_F(ImplParserSimpleClassTest, DoWork_HasEarlyReturn)
{
    auto* m = FindPublic("DoWork");
    ASSERT_NE(m, nullptr);
    EXPECT_TRUE(HasBranchKind(m->branchHints, BranchKind::EarlyReturn));
}

TEST_F(ImplParserSimpleClassTest, ValidateInput_HasBranchHints)
{
    auto* m = FindPrivate("ValidateInput");
    ASSERT_NE(m, nullptr);
    EXPECT_THAT(m->branchHints, Not(IsEmpty()));
}

TEST_F(ImplParserSimpleClassTest, ValidateInput_ConditionsReferenceValue)
{
    auto* m = FindPrivate("ValidateInput");
    ASSERT_NE(m, nullptr);
    // At least one hint should mention the condition about value
    bool found = std::any_of(m->branchHints.begin(), m->branchHints.end(),
                             [](const BranchHint& h)
                             { return h.condition.find("value") != std::string::npos; });
    EXPECT_TRUE(found) << "Expected at least one hint mentioning 'value'";
}

TEST_F(ImplParserSimpleClassTest, GetCount_NoHints)
{
    // GetCount just returns m_count – no branches
    auto* m = FindPublic("GetCount");
    ASSERT_NE(m, nullptr);
    EXPECT_THAT(m->branchHints, IsEmpty());
}

TEST_F(ImplParserSimpleClassTest, Reset_NoHints)
{
    auto* m = FindPublic("Reset");
    ASSERT_NE(m, nullptr);
    EXPECT_THAT(m->branchHints, IsEmpty());
}

TEST_F(ImplParserSimpleClassTest, Categorise_HasSwitchHint)
{
    auto* m = FindPublic("Categorise");
    ASSERT_NE(m, nullptr) << "Categorise() not found – check fixture header/cpp";
    EXPECT_THAT(m->branchHints, Not(IsEmpty()));
}

TEST_F(ImplParserSimpleClassTest, Categorise_HasCaseBranches)
{
    auto* m = FindPublic("Categorise");
    ASSERT_NE(m, nullptr);
    EXPECT_TRUE(HasBranchKind(m->branchHints, BranchKind::SwitchCase))
        << "Expected SwitchCase hints for case 0/1/2";
}

TEST_F(ImplParserSimpleClassTest, Categorise_HasDefaultBranch)
{
    auto* m = FindPublic("Categorise");
    ASSERT_NE(m, nullptr);
    EXPECT_TRUE(HasBranchKind(m->branchHints, BranchKind::DefaultCase))
        << "Expected DefaultCase hint for default:";
}

TEST_F(ImplParserSimpleClassTest, Categorise_HasSwitchConditionHint)
{
    auto* m = FindPublic("Categorise");
    ASSERT_NE(m, nullptr);
    // The switch condition itself should be captured
    EXPECT_TRUE(HasBranchKind(m->branchHints, BranchKind::IfCondition))
        << "Expected IfCondition hint for switch(value)";
}

TEST_F(ImplParserSimpleClassTest, Categorise_CaseValuesExtracted)
{
    auto* m = FindPublic("Categorise");
    ASSERT_NE(m, nullptr);
    // At least one SwitchCase hint should have a non-empty condition
    bool found = std::any_of(m->branchHints.begin(), m->branchHints.end(),
        [](const BranchHint& h)
        {
            return h.kind == BranchKind::SwitchCase && !h.condition.empty();
        });
    EXPECT_TRUE(found) << "Case values should be extracted as non-empty conditions";
}
{
    for (auto& method : m_em.publicMethods)
        for (auto& h : method.branchHints)
            EXPECT_FALSE(h.description.empty())
                << "Empty description in " << method.name;

    for (auto& method : m_em.privateMethods)
        for (auto& h : method.branchHints)
            EXPECT_FALSE(h.description.empty())
                << "Empty description in " << method.name;
}

// ===========================================================================
// Edge cases
// ===========================================================================

TEST(ImplParserEdgeCases, NonExistentFileReturnsFalse)
{
    std::vector<MethodInfo> pub, priv;
    bool ok = ImplParser::Parse("no_such_file.cpp", "SomeClass", pub, priv);
    EXPECT_FALSE(ok);
}

TEST(ImplParserEdgeCases, EmptyMethodListsAreUntouched)
{
    std::vector<MethodInfo> pub, priv;
    // Even a missing file returns false but doesn't crash
    ImplParser::Parse("no_such_file.cpp", "SomeClass", pub, priv);
    EXPECT_THAT(pub,  IsEmpty());
    EXPECT_THAT(priv, IsEmpty());
}

// ===========================================================================
// Parameterised: BranchKind label strings
// ===========================================================================

struct BranchKindLabelCase
{
    BranchKind  kind;
    std::string expectedSubstr;
};

class BranchKindLabelTest : public ::testing::TestWithParam<BranchKindLabelCase> {};

TEST_P(BranchKindLabelTest, LabelIsNonEmpty)
{
    const char* label = BranchKindLabel(GetParam().kind);
    ASSERT_NE(label, nullptr);
    EXPECT_THAT(std::string(label), Not(IsEmpty()));
}

TEST_P(BranchKindLabelTest, LabelContainsExpectedSubstring)
{
    const char* label = BranchKindLabel(GetParam().kind);
    EXPECT_NE(std::string(label).find(GetParam().expectedSubstr), std::string::npos)
        << "Label '" << label << "' does not contain '" << GetParam().expectedSubstr << "'";
}

INSTANTIATE_TEST_SUITE_P(
    AllKinds,
    BranchKindLabelTest,
    ::testing::Values(
        BranchKindLabelCase{ BranchKind::IfCondition,   "if"      },
        BranchKindLabelCase{ BranchKind::ElseClause,    "else"    },
        BranchKindLabelCase{ BranchKind::SwitchCase,    "case"    },
        BranchKindLabelCase{ BranchKind::DefaultCase,   "default" },
        BranchKindLabelCase{ BranchKind::EarlyReturn,   "return"  },
        BranchKindLabelCase{ BranchKind::TernaryTrue,   "ternary" },
        BranchKindLabelCase{ BranchKind::TernaryFalse,  "ternary" },
        BranchKindLabelCase{ BranchKind::LoopCondition, "loop"    }
    ),
    [](const ::testing::TestParamInfo<BranchKindLabelTest::ParamType>& i)
    {
        // Derive a clean test name from the label
        std::string name = BranchKindLabel(i.param.kind);
        for (char& c : name) if (!std::isalnum(c)) c = '_';
        return name;
    }
);

// ===========================================================================
// Parameterised: per-method hint count expectations for SimpleClass
// ===========================================================================

struct MethodHintExpectation
{
    std::string methodName;
    bool        isPrivate;
    int         minExpectedHints;  // lower bound; we don't hard-code exact counts
};

class ImplParserHintCountTest
    : public ::testing::TestWithParam<MethodHintExpectation>
{
protected:
    EnrichedMethods m_em;

    void SetUp() override
    {
        m_em = RunImplParser("SimpleClass.h", "SimpleClass.cpp");
        ASSERT_TRUE(m_em.parseOk && m_em.implOk);
    }
};

TEST_P(ImplParserHintCountTest, HintCountMeetsMinimum)
{
    const auto& p = GetParam();
    const auto& methods = p.isPrivate ? m_em.privateMethods : m_em.publicMethods;

    auto it = std::find_if(methods.begin(), methods.end(),
                            [&](const MethodInfo& m){ return m.name == p.methodName; });
    ASSERT_NE(it, methods.end()) << "Method not found: " << p.methodName;

    EXPECT_GE(static_cast<int>(it->branchHints.size()), p.minExpectedHints)
        << p.methodName << " has fewer branch hints than expected";
}

INSTANTIATE_TEST_SUITE_P(
    SimpleClassMethods,
    ImplParserHintCountTest,
    ::testing::Values(
        // DoWork has: if(!ValidateInput), else-of-that, if(value>100), else-if, else,
        // early return false, early return true → expect at least 4 hints
        MethodHintExpectation{ "DoWork",        false, 4 },
        // ValidateInput has two if-conditions each with implicit else, plus two early returns
        MethodHintExpectation{ "ValidateInput", true,  3 },
        // GetCount and Reset have no branches
        MethodHintExpectation{ "GetCount",      false, 0 },
        MethodHintExpectation{ "Reset",         false, 0 }
    ),
    [](const ::testing::TestParamInfo<ImplParserHintCountTest::ParamType>& i)
    {
        return i.param.methodName + (i.param.isPrivate ? "_Private" : "_Public");
    }
);
