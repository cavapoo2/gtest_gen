# GTestGen — C++ Parameterised Test Scaffold Generator

Generates Google Test / GMock scaffolding from a C++ class header.

## Solution layout

```
GTestGen.sln
├── GTestGen/                  <- Console tool (the generator)
│   ├── main.cpp               <- CLI entry point
│   ├── ClassParser.h/.cpp     <- Parses a C++ class header
│   ├── TestGenerator.h/.cpp   <- Emits the four output files
│   ├── TemplateEngine.h       <- Lightweight {{KEY}} templating
│   └── GeneratorConfig.h      <- Data model (ClassInfo, MethodInfo, …)
│
└── GTestGenTests/             <- GTest project that tests the generator itself
    ├── TestMain.cpp
    ├── ParserTests.cpp        <- Parameterised tests for ClassParser
    ├── GeneratorTests.cpp     <- Parameterised integration tests for TestGenerator
    └── fixtures/              <- Minimal header files used as parse inputs
        ├── SimpleClass.h
        └── MultiInterfaceClass.h
```

## Prerequisites

| Requirement | Version |
|---|---|
| Visual Studio | 2022 (v143 toolset) |
| Windows SDK | 10.0 |
| C++ standard | C++17 |
| Google Test / GMock | 1.14+ |

## Getting Google Test (choose one)

### Option A — NuGet (recommended for Visual Studio)

In VS: **Tools → NuGet Package Manager → Manage Packages for Solution**  
Search for `Microsoft.googletest.v140.windesktop.msvcstl.dyn.rt-dyn` and install
into `GTestGenTests`.

### Option B — vcpkg

```cmd
vcpkg install gtest:x64-windows
vcpkg integrate install
```

Then in `GTestGenTests.vcxproj` replace the manual lib paths with:
```xml
<Import Project="$(VCTargetsPath)\Microsoft.Cpp.props" />
```
vcpkg integration injects the paths automatically.

### Option C — Manual build (matches the .vcxproj defaults)

```cmd
git clone https://github.com/google/googletest.git third_party\googletest
cd third_party\googletest
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Debug
cmake --build build --config Release
```

The `.vcxproj` expects libraries at:
```
third_party\googletest\build\lib\Debug\gtestd.lib
third_party\googletest\build\lib\Debug\gmockd.lib
```

## Build

Open `GTestGen.sln` in Visual Studio 2022 and press **Ctrl+Shift+B**.

Or from a Developer Command Prompt:

```cmd
msbuild GTestGen.sln /p:Configuration=Release /p:Platform=x64
```

Output binary: `bin\x64\Release\GTestGen.exe`

## Usage

```
GTestGen.exe <HeaderFile.h> [options]

Options:
  -o <dir>          Output directory           (default: ./generated)
  --namespace <ns>  Namespace for test code    (default: none)
  --cmake           Also emit CMakeLists.txt
  --verbose         Verbose logging
  --help            This message
```

### Example

```cmd
GTestGen.exe path\to\UserService.h -o tests\generated --cmake --verbose
```

Produces:

| File | Purpose |
|---|---|
| `MockInterfaces.h` | GMock classes for every detected interface |
| `UserServiceTestFixture.h` | `TestWithParam<>` fixture, `friend` of the CUT |
| `UserServiceTests.cpp` | `TEST_P` for every public + private method |
| `CMakeLists.txt` | Build snippet (with `--cmake`) |

## Post-generation checklist

1. **Add `friend` declaration** — open your real class header and add:
   ```cpp
   friend class UserServiceTests;   // or whatever the class is named
   ```
   The fixture header shows you exactly where.

2. **Fill in `MOCK_METHOD` entries** — open `MockInterfaces.h` and add one
   `MOCK_METHOD` line per pure virtual in each interface.  
   GMock 3 syntax:
   ```cpp
   MOCK_METHOD(bool, Login, (const std::string& user, const std::string& pw), (override));
   ```

3. **Extend `UserServiceTestParams`** — add fields for inputs and expected outputs,
   then populate `INSTANTIATE_TEST_SUITE_P` with real values.

4. **Set up `EXPECT_CALL` stubs** in each `TEST_P` and replace the placeholder
   `EXPECT_EQ` with real assertions.

5. **Run the tests** — all stubs compile and emit `SUCCEED()` immediately, so
   the baseline build should be green before you add real assertions.

## How private-method access works

The generator makes the fixture a `friend class` of the class under test.
For each private method it emits a thin public wrapper in the fixture:

```cpp
// In UserServiceTestFixture.h
bool Call_ValidateUserName(const std::string& name)
{
    return m_sut->ValidateUserName(name);   // calls the real private impl
}
```

In the test:
```cpp
TEST_P(UserServiceTests, Private_ValidateUserName)
{
    auto result = Call_ValidateUserName("alice");
    EXPECT_TRUE(result);
}
```

The real production code runs — no stubs, no workarounds.

## Running GTestGenTests

The `GTestGenTests` project tests the parser and generator themselves.
Build and run with:

```cmd
bin\x64\Debug\GTestGenTests.exe --gtest_output=xml:results.xml
```

Or via VS **Test Explorer** (requires the Google Test adapter extension).
